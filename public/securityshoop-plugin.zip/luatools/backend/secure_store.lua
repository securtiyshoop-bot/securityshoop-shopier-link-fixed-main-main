local fs = require("fs")
local m_utils = require("utils")
local paths = require("paths")
local win_process = require("win_process")

local store = {}
local TOKEN_FILE = paths.backend_path("data/account-token.dpapi")
local SCRIPT_FILE = paths.backend_path("scripts/dpapi_store.ps1")

local function quote(value)
    return '"' .. tostring(value or ""):gsub('"', '\\"') .. '"'
end

local function unique_temp(label)
    return paths.backend_path("data/" .. label .. "-" .. tostring(os.time()) .. "-" .. tostring(math.random(100000, 999999)) .. ".tmp")
end

local function run_hidden(operation, input_file, output_file)
    if not fs.exists(SCRIPT_FILE) then return false, "DPAPI helper bulunamadi." end
    local arguments =
        "-Operation " .. quote(operation) ..
        " -InputFile " .. quote(input_file) ..
        " -OutputFile " .. quote(output_file)
    local ok, result = win_process.powershell_file(SCRIPT_FILE, arguments, true)
    if not ok then return false, "DPAPI helper calistirilamadi: " .. tostring(result or "") end
    return fs.exists(output_file), fs.exists(output_file) and "" or "DPAPI cikti dosyasi olusmadi."
end

function store.exists()
    return fs.exists(TOKEN_FILE)
end

function store.protect(token)
    token = tostring(token or "")
    if token == "" then return false, "Bos token korunamaz." end
    local plain_file = unique_temp("dpapi-plain")
    m_utils.write_file(plain_file, token)
    local ok, err = run_hidden("protect", plain_file, TOKEN_FILE)
    pcall(fs.remove, plain_file)
    return ok, err
end

function store.unprotect()
    if not fs.exists(TOKEN_FILE) then return "", "DPAPI token dosyasi yok." end
    local output_file = unique_temp("dpapi-result")
    local ok, err = run_hidden("unprotect", TOKEN_FILE, output_file)
    if not ok then
        pcall(fs.remove, output_file)
        return "", err
    end
    local token = tostring(m_utils.read_file(output_file) or ""):match("^%s*(.-)%s*$") or ""
    pcall(fs.remove, output_file)
    return token, token ~= "" and "" or "DPAPI token bos dondu."
end

function store.clear()
    pcall(fs.remove, TOKEN_FILE)
    return true
end

return store
