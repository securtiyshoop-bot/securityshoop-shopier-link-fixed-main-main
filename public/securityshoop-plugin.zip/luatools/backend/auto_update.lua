local http_client = require("http_client")
local config = require("config")
local logger = require("plugin_logger")
local paths = require("paths")
local utils = require("plugin_utils")
local fs = require("fs")
local win_process = require("win_process")

local auto_update = {}
local DATA_DIR = paths.backend_path("data")
local UPDATE_STATE_FILE = paths.backend_path("data/update-state.json")
local HEALTH_FILE = paths.backend_path("data/update-health-ok.json")

local function quote(value)
    return '"' .. tostring(value or ""):gsub('"', '\\"') .. '"'
end

local function local_pending_file()
    local base = os.getenv("LOCALAPPDATA") or ""
    if base == "" then return "" end
    return fs.join(base, "SecurityShoop", "rollback", "pending.json")
end

function auto_update.check_for_updates_now()
    local cfg_path = paths.backend_path(config.UPDATE_CONFIG_FILE)
    local cfg = utils.read_json(cfg_path)
    local latest_version = ""
    local zip_url = ""
    local gh_cfg = cfg.github
    if gh_cfg then
        local owner = gh_cfg.owner or ""
        local repo = gh_cfg.repo or ""
        local asset_name = gh_cfg.asset_name or "ltsteamplugin.zip"
        local endpoint = "https://api.github.com/repos/" .. owner .. "/" .. repo .. "/releases/latest"
        local resp = http_client.get(endpoint, { headers = { ["Accept"] = "application/vnd.github+json", ["User-Agent"] = "SecurityShoop-Updater" }, timeout = 10 })
        if resp and resp.status == 200 and resp.body then
            local data = utils.decode_json(resp.body)
            latest_version = tostring(data.tag_name or data.name or ""):gsub("^v", "")
            for _, asset in ipairs(data.assets or {}) do
                if asset.name == asset_name then zip_url = asset.browser_download_url break end
            end
        end
    end
    if latest_version == "" or zip_url == "" then return { success = false, error = "Imzali guncelleme bilgisi bulunamadi." } end
    return { success = true, update_available = true, latest_version = latest_version, current_version = utils.get_plugin_version(), zip_url = zip_url }
end

local function launch_hidden(script_path, arguments, wait)
    local ok = win_process.powershell_file(script_path, tostring(arguments or ""), wait == true)
    return ok == true
end

function auto_update.restart_steam()
    local pending = local_pending_file()
    if pending ~= "" and fs.exists(pending) then
        local watchdog = paths.backend_path("scripts/rollback_watchdog.ps1")
        launch_hidden(watchdog, "-PendingFile " .. quote(pending), false)
    end

    -- COZUM: Iki adimli WMI yaklasimi
    -- 1) inner_restart.ps1: Steam'i durdurur ve yeniden baslatir
    -- 2) launcher (restart_steam_hidden.ps1): WMI.Create ile inner'i parent'siz baslatir
    -- WMI ile baslayan process Steam'e baglanmaz, Steam kapansa da calisir.

    local inner_ps1    = paths.backend_path("restart_steam_inner.ps1")
    local launcher_ps1 = paths.backend_path("restart_steam_hidden.ps1")

    -- Asil restart scripti
    local inner_script = table.concat({
        "$ErrorActionPreference='SilentlyContinue'",
        "$p=$null",
        "try{$p=(Get-ItemProperty 'HKCU:\\Software\\Valve\\Steam' -Name SteamPath).SteamPath}catch{}",
        "if(!$p){$p=(Get-ItemProperty 'HKLM:\\Software\\Valve\\Steam' -Name InstallPath).InstallPath}",
        "$e=if($p){Join-Path $p 'steam.exe'}else{$null}",
        "Stop-Process -Name steam -Force",
        "Start-Sleep 4",
        "if($e -and (Test-Path $e)){Start-Process $e}else{Start-Process 'steam://open/main'}",
    }, "\r\n") .. "\r\n"
    utils.write_text(inner_ps1, inner_script)

    -- Launcher: WMI ile inner scripti parent'siz calistir
    -- Lua string'inde cift tirnak kacinmak icin concat kullaniriz
    local launcher_script = table.concat({
        "$wmi=[wmiclass]'Win32_Process'",
        '$ps="$env:SystemRoot\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"',
        "$f='" .. inner_ps1 .. "'",
        '$null=$wmi.Create("$ps -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$f`"")',
    }, "\r\n") .. "\r\n"
    utils.write_text(launcher_ps1, launcher_script)

    local ok = launch_hidden(launcher_ps1, "", false)
    if ok then return true, "Steam WMI ile yeniden baslatiliyor." end
    return false, "Steam yeniden baslatma baslatilamadi."
end
function auto_update.apply_update(zip_url, latest_version, expected_sha256)
    zip_url = tostring(zip_url or "")
    expected_sha256 = tostring(expected_sha256 or ""):lower()
    if not zip_url:match("^https://securityshoop%.vercel%.app/") then
        return { success = false, applied = false, error = "Guncelleme yalnizca sabitlenmis SecurityShoop kaynagindan alinabilir." }
    end
    if not expected_sha256:match("^[a-f0-9]+$") or #expected_sha256 ~= 64 then
        return { success = false, applied = false, error = "Imzali SHA-256 bilgisi gecersiz." }
    end
    local request_file = paths.backend_path("data/update-request.json")
    utils.write_json(request_file, {
        url = zip_url,
        expectedSha256 = expected_sha256,
        latestVersion = tostring(latest_version or ""),
        currentVersion = utils.get_plugin_version(),
        pluginDir = paths.get_plugin_dir(),
        stateFile = UPDATE_STATE_FILE,
        healthFile = HEALTH_FILE,
        oldSteamPid = ""
    })
    local updater = paths.backend_path("scripts/plugin_update.ps1")
    if not fs.exists(updater) then return { success = false, error = "Guvenli guncelleme yardimcisi bulunamadi." } end
    local launched = launch_hidden(updater, "-RequestFile " .. quote(request_file), false)
    if not launched then return { success = false, error = "Guvenli guncelleme baslatilamadi." } end
    return { success = true, applied = false, applying = true, latest_version = latest_version, message = "Imzali guncelleme indiriliyor; tamamlaninca Steam'i yeniden baslat." }
end

function auto_update.apply_pending_update_if_any()
    local pending = local_pending_file()
    if pending ~= "" and fs.exists(pending) then return "Guncelleme saglik kontrolu bekliyor." end
    return ""
end

function auto_update.mark_current_boot_healthy()
    utils.write_json(HEALTH_FILE, { version = utils.get_plugin_version(), healthy = true, at = os.date("!%Y-%m-%dT%H:%M:%SZ") })
    return true
end

return auto_update
