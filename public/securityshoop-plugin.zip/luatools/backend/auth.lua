local cjson = require("json")
local fs = require("fs")
local http_client = require("http_client")
local logger = require("plugin_logger")
local paths = require("paths")
local utils = require("plugin_utils")
local game_registry = require("game_registry")
local secure_store = require("secure_store")

local auth = {}

local SITE_URL = "https://securityshoop.vercel.app"
local BACKEND_SITE_HTTP_ENABLED = false
local ACCOUNT_FILE = paths.backend_path("data/account.json")
local CONTROL_CACHE_FILE = paths.backend_path("data/plugin-control.json")
local PLUGIN_VERSION = "8.5.2"
local CONTROL_CACHE = { value = nil, expires_at = 0 }
local TOKEN_CACHE = nil

local function now()
    return os.date("!%Y-%m-%dT%H:%M:%SZ")
end

local function ensure_parent_dir(path)
    local dir = fs.parent_path(path)
    if dir and dir ~= "" and not fs.exists(dir) then fs.create_directories(dir) end
end

local function read_account()
    local data = utils.read_json(ACCOUNT_FILE)
    if type(data) ~= "table" then data = {} end
    local plain_token = tostring(data.token or "")
    if plain_token ~= "" then
        TOKEN_CACHE = plain_token
        local protected = secure_store.protect(plain_token)
        if protected then
            data.token = nil
            data.token_protected = true
            ensure_parent_dir(ACCOUNT_FILE)
            utils.write_json(ACCOUNT_FILE, data)
        end
    elseif TOKEN_CACHE == nil and data.token_protected == true then
        local token, err = secure_store.unprotect()
        if token ~= "" then
            TOKEN_CACHE = token
        else
            TOKEN_CACHE = ""
            logger.warn("SecurityShoop: DPAPI token could not be opened: " .. tostring(err or ""))
        end
    end
    data.token = TOKEN_CACHE or plain_token
    if not data.hwid or data.hwid == "" then
        math.randomseed(os.time())
        data.hwid = "ss-" .. tostring(os.time()) .. "-" .. tostring(math.random(100000, 999999))
        ensure_parent_dir(ACCOUNT_FILE)
        local runtime_token = data.token
        if data.token_protected == true then data.token = nil end
        utils.write_json(ACCOUNT_FILE, data)
        data.token = runtime_token
    end
    return data
end

local function write_account(data)
    ensure_parent_dir(ACCOUNT_FILE)
    data = data or {}
    local token = tostring(data.token or "")
    local disk = {}
    for key, value in pairs(data) do
        if key ~= "token" then disk[key] = value end
    end
    if token ~= "" then
        local protected = secure_store.exists()
        if TOKEN_CACHE ~= token or not protected then
            protected = secure_store.protect(token)
        end
        if protected then
            TOKEN_CACHE = token
            disk.token_protected = true
        else
            disk.token = token
            disk.token_protected = false
            logger.warn("SecurityShoop: DPAPI unavailable; token migration was not completed.")
        end
    elseif data.token_protected == true and secure_store.exists() then
        disk.token_protected = true
    else
        TOKEN_CACHE = ""
        disk.token_protected = false
        secure_store.clear()
    end
    utils.write_json(ACCOUNT_FILE, disk)
end

local function trim(value)
    local text = tostring(value or "")
    text = text:gsub("^\239\187\191", "")
    return text:match("^%s*(.-)%s*$") or ""
end

local function preview(value)
    local text = trim(value)
    if #text > 180 then return text:sub(1, 180) .. "..." end
    return text
end

local function response_status(resp)
    if type(resp) ~= "table" then return 0 end
    return tonumber(resp.status or resp.status_code or resp.code or resp.response_code or 0) or 0
end

local function response_body(resp)
    if type(resp) == "string" then return resp end
    if type(resp) ~= "table" then return "" end
    local values = { resp.body, resp.text, resp.content, resp.data, resp.error }
    for _, value in ipairs(values) do
        if value ~= nil and tostring(value) ~= "" then
            return tostring(value)
        end
    end
    return ""
end

local function url_encode(value)
    local text = tostring(value or "")
    text = text:gsub("\n", "\r\n")
    text = text:gsub("([^%w%-%_%.%~])", function(char)
        return string.format("%%%02X", string.byte(char))
    end)
    return text
end

local function site_error(message, status, body, extra)
    local clean_status = tonumber(status or 0) or 0
    local details = message
    if clean_status > 0 then details = details .. " (HTTP " .. tostring(clean_status) .. ")" end
    local body_preview = preview(body)
    if body_preview ~= "" then
        logger.warn("SecurityShoop site response was not usable: " .. details .. " body=" .. body_preview)
    else
        logger.warn("SecurityShoop site response was not usable: " .. details)
    end
    return {
        ok = false,
        site_unavailable = true,
        message = extra or details,
        status = clean_status,
        raw_preview = body_preview
    }, clean_status
end

local function decode_response(resp, path)
    if not resp then
        return site_error("Siteye baglanilamadi.", 0, "", "SecurityShoop sitesine baglanilamadi.")
    end

    local status = response_status(resp)
    local body = response_body(resp)
    local clean_body = trim(body)

    if clean_body ~= "" then
        local ok, parsed = pcall(cjson.decode, clean_body)
        if ok and type(parsed) == "table" then
            local parsed_message = tostring(parsed.message or parsed.error or "")
            if parsed_message:find("Plugin API", 1, true) ~= nil or parsed_message:find("plugin/control", 1, true) ~= nil then
                if tostring(path or ""):find("heartbeat", 1, true) then
                    return {
                        ok = true,
                        authenticated = false,
                        status = nil,
                        commands = {},
                        message = ""
                    }, status
                end
                return site_error(
                    "Plugin API endpoint eksik.",
                    status,
                    body,
                    "SecurityShoop site kontrol API'si yok; yerel mod kullaniliyor."
                )
            end
            return parsed, status
        end
    end

    if status == 404 or status == 405 or clean_body:lower():find("<!doctype", 1, true) or clean_body:lower():find("<html", 1, true) then
        return site_error(
            "Site JSON yerine HTML/404 dondurdu.",
            status,
            body,
            "SecurityShoop sitesi guncel degil. Yeni site ZIP'ini Vercel'e deploy et."
        )
    end

    if status == 400 then
        local endpoint = tostring(path or "")
        if endpoint:find("login", 1, true) then
            return { ok = false, message = "E-posta/kullanici adi veya sifre hatali." }, status
        end
        if endpoint:find("register", 1, true) then
            return { ok = false, message = "Kayit bilgileri hatali veya bu hesap zaten var." }, status
        end
        return { ok = false, message = "Istek hatali." }, status
    end

    if tostring(path or ""):find("heartbeat", 1, true) and (status == 0 or status == 401 or status == 403) then
        return {
            ok = true,
            authenticated = false,
            status = nil,
            commands = {},
            message = ""
        }, status
    end

    if status == 401 or status == 403 then
        return { ok = false, blocked = status == 403, message = "Bu hesapla islem yapilamadi." }, status
    end

    return site_error("Site cevabi okunamadi: " .. tostring(path or ""), status, body)
end

local function rpc_fallback_allowed(path)
    return false
end

local function should_try_rpc_fallback(path, payload, status)
    if not rpc_fallback_allowed(path) then return false end
    local clean_status = tonumber(status or 0) or 0
    if clean_status == 404 or clean_status == 405 then return true end
    if payload and payload.site_unavailable == true then
        local message = tostring(payload.message or payload.error or "")
        if message:find("kontrol API", 1, true) ~= nil then return true end
        if message:find("guncel degil", 1, true) ~= nil then return true end
        if message:find("endpoint", 1, true) ~= nil then return true end
    end
    local message = tostring((payload and (payload.message or payload.error)) or "")
    return message:find("Plugin API", 1, true) ~= nil or message:find("endpoint", 1, true) ~= nil
end

local function compact_rpc_payload(path, body, original_payload)
    local endpoint = tostring(path or "")
    -- Heartbeat disindaki tum endpointler icin orijinal body'yi kullan
    if endpoint:find("/api/plugin/heartbeat", 1, true) ~= 1 then
        return body or "{}"
    end
    if type(original_payload) ~= "table" then return body or "{}" end

    local compact = {
        token = original_payload.token or "",
        email = original_payload.email or "",
        hwid = original_payload.hwid or "",
        version = original_payload.version or PLUGIN_VERSION,
        status = original_payload.status or "online",
        appid = tostring(original_payload.appid or ""),
        current_api = tostring(original_payload.current_api or ""),
        message = tostring(original_payload.message or "")
    }
    if type(original_payload.installed_games) == "table" then
        local count = 0
        for _ in pairs(original_payload.installed_games) do count = count + 1 end
        compact.installed_games_count = count
    end
    if type(original_payload.source_health) == "table" then
        local ok_health, health_body = pcall(cjson.encode, original_payload.source_health)
        if ok_health and #tostring(health_body or "") < 1500 then
            compact.source_health = original_payload.source_health
        end
    end

    local ok_compact, compact_body = pcall(cjson.encode, compact)
    if ok_compact then return compact_body end
    return body or "{}"
end

local function get_json_via_rpc(path, body, timeout, original_payload)
    local rpc_body = compact_rpc_payload(path, body, original_payload)
    local endpoint = SITE_URL ..
        "/api/plugin/rpc?path=" .. url_encode(path) ..
        "&payload=" .. url_encode(rpc_body or "{}")
    local is_auth = tostring(path or ""):find("login", 1, true) or tostring(path or ""):find("register", 1, true)
    if #endpoint > 7500 then
        if tostring(path or ""):find("heartbeat", 1, true) then
            return { ok = true, authenticated = false, status = nil, commands = {}, message = "" }, 0
        end
        if is_auth then
            return site_error("Giris istegi cok uzun.", 0, "", "E-posta veya sifre cok uzun.")
        end
        return site_error("Site RPC istegi cok uzun.", 0, "", "SecurityShoop RPC istegi cok uzun; yerel mod kullaniliyor.")
    end
    local ok, resp = pcall(http_client.get, endpoint, {
        headers = {
            ["Accept"] = "application/json",
            ["User-Agent"] = "SecurityShoopPlugin/" .. PLUGIN_VERSION
        },
        timeout = timeout or 20
    })
    if not ok then
        if tostring(path or ""):find("heartbeat", 1, true) then
            return { ok = true, authenticated = false, status = nil, commands = {}, message = "" }, 0
        end
        if is_auth then
            return site_error("Siteye baglanilamadi.", 0, "", "SecurityShoop sitesine ulasilamadi. Internet baglantini kontrol et.")
        end
        return site_error("Site RPC istegi basarisiz: " .. tostring(resp), 0, "", "SecurityShoop sitesine baglanilamadi.")
    end
    return decode_response(resp, path)
end

local function local_backend_site_response(path)
    local endpoint = tostring(path or "")
    if endpoint:find("heartbeat", 1, true) then
        return {
            ok = true,
            authenticated = false,
            status = { local_only = true },
            commands = {},
            message = ""
        }, 0
    end
    if endpoint:find("control", 1, true) or endpoint:find("account-status", 1, true) then
        return {
            ok = false,
            site_unavailable = true,
            message = "Yerel mod kullaniliyor.",
            status = 0
        }, 0
    end
    if endpoint == "/api/log-action" or endpoint:find("/ack", 1, true) then
        return { ok = true, message = "" }, 0
    end
    if endpoint:find("error-report", 1, true) then
        return { ok = true, message = "Yerel modda hata raporu atlandi." }, 0
    end
    if endpoint:find("notifications", 1, true) then
        return { ok = true, notifications = {}, count = 0, message = "" }, 0
    end
    if endpoint:find("login", 1, true) or endpoint:find("register", 1, true) then
        return {
            ok = false,
            site_unavailable = true,
            message = "SecurityShoop site girisi tarayici uzerinden deneniyor.",
            status = 0
        }, 0
    end
    return {
        ok = false,
        site_unavailable = true,
        message = "Yerel mod kullaniliyor.",
        status = 0
    }, 0
end

local function post_json(path, payload, timeout)
    if BACKEND_SITE_HTTP_ENABLED ~= true then
        -- Login ve register icin RPC proxy uzerinden siteye gid
        local endpoint = tostring(path or "")
        if endpoint:find("login", 1, true) or endpoint:find("register", 1, true) then
            local ok_encode, body = pcall(cjson.encode, payload or {})
            if not ok_encode then
                return { ok = false, message = "Istek hazirlanamadi.", status = 0 }, 0
            end
            return get_json_via_rpc(path, body, timeout or 20, payload)
        end
        return local_backend_site_response(path)
    end
    local ok_encode, body = pcall(cjson.encode, payload or {})
    if not ok_encode then
        return { ok = false, message = "Istek hazirlanamadi.", status = 0 }, 0
    end

    local endpoint = SITE_URL .. tostring(path or "")
    local ok, resp = pcall(http_client.post, endpoint, {
        headers = {
            ["Accept"] = "application/json",
            ["Content-Type"] = "application/json",
            ["User-Agent"] = "SecurityShoopPlugin/" .. PLUGIN_VERSION
        },
        data = body,
        timeout = timeout or 20
    })
    if not ok then
        if tostring(path or ""):find("heartbeat", 1, true) then
            return { ok = true, authenticated = false, status = nil, commands = {}, message = "" }, 0
        end
        return site_error("Site istegi basarisiz: " .. tostring(resp), 0, "", "SecurityShoop sitesine baglanilamadi.")
    end
    local decoded, status = decode_response(resp, path)
    if should_try_rpc_fallback(path, decoded, status) then
        logger.info("SecurityShoop: direct site API missing, retrying through RPC for " .. tostring(path or ""))
        return get_json_via_rpc(path, body, timeout, payload)
    end
    return decoded, status
end

local function public_user(user)
    user = user or {}
    return {
        id = user.id,
        username = user.username or "",
        email = user.email or "",
        role = user.role or "user",
        token = user.token or "",
        license_until = user.license_until or "",
        daily_limit = user.daily_limit or 0,
        game_limit = user.game_limit or user.limit or 0,
        allowed_appids = user.allowed_appids or {},
        approval_status = user.approval_status or "approved"
    }
end

local function store_user(account, user)
    local public = public_user(user)
    account.id = public.id
    account.username = public.username
    account.email = public.email
    account.role = public.role
    account.token = public.token
    account.license_until = public.license_until
    account.daily_limit = public.daily_limit
    account.game_limit = public.game_limit
    account.allowed_appids = public.allowed_appids
    account.approval_status = public.approval_status
    account.remote_blocked = false
    account.remote_block_message = ""
    account.updated_at = now()
    write_account(account)
    CONTROL_CACHE.value = nil
    CONTROL_CACHE.expires_at = 0
    return public
end

local function should_fallback_to_site_auth(payload, status)
    if payload and payload.site_unavailable then return true end
    if tonumber(status or 0) == 404 or tonumber(status or 0) == 405 then return true end
    local message = tostring((payload and payload.message) or "")
    return message:find("Plugin API", 1, true) ~= nil
end

function auth.get_account()
    local account = read_account()
    return {
        success = true,
        authenticated = type(account.token) == "string" and account.token ~= "",
        user = {
            id = account.id,
            username = account.username or "",
            email = account.email or "",
            role = account.role or "user",
            token = account.token or "",
            license_until = account.license_until or "",
            daily_limit = account.daily_limit or 0,
            game_limit = account.game_limit or 0,
            allowed_appids = account.allowed_appids or {},
            approval_status = account.approval_status or "approved"
        },
        hwid = account.hwid or ""
    }
end

function auth.register(username, email, password, confirm_password)
    local account = read_account()
    username = tostring(username or "")
    email = tostring(email or "")
    password = tostring(password or "")
    confirm_password = tostring(confirm_password or password or "")
    if username == "" or email == "" or password == "" then
        return { success = false, error = "Kayit bilgileri plugin tarafinda eksik okundu. Tekrar dene." }
    end
    local payload, status = post_json("/api/plugin/register", {
        username = username,
        email = email,
        password = password,
        confirmPassword = confirm_password,
        hwid = account.hwid
    })

    if not payload.ok then
        local message = tostring(payload.message or payload.error or "")
        local lower_message = message:lower()
        if lower_message:find("kayitli", 1, true) or lower_message:find("kayÄ±tlÄ±", 1, true) or lower_message:find("already", 1, true) then
            local login_result = auth.login(email, password)
            if login_result and login_result.success then
                login_result.message = "Hesap zaten vardi, giris yapildi."
                return login_result
            end
        end
    end

    if not payload.ok then
        return { success = false, status = status, error = payload.message or "Kayit basarisiz." }
    end
    if payload.pending_approval == true then
        account.email = email
        account.username = username
        account.approval_status = "pending"
        account.updated_at = now()
        write_account(account)
        return { success = false, pending_approval = true, status = status, error = payload.message or "Hesap admin onayi bekliyor.", message = payload.message or "Hesap admin onayi bekliyor.", hwid = account.hwid }
    end
    local user = store_user(account, payload.user)
    if not user.token or user.token == "" then
        local login_payload = post_json("/api/plugin/login", {
            email = tostring(email or ""),
            login = tostring(email or ""),
            password = tostring(password or ""),
            hwid = account.hwid
        })
        if login_payload and login_payload.ok and login_payload.user then
            user = store_user(account, login_payload.user)
        end
    end
    return { success = true, user = user, hwid = account.hwid, message = payload.message or "Hesap olusturuldu." }
end

function auth.login(email, password)
    local account = read_account()
    email = tostring(email or "")
    password = tostring(password or "")
    if email == "" or password == "" then
        return { success = false, error = "Giris bilgileri plugin tarafinda eksik okundu. Tekrar dene." }
    end
    local payload, status = post_json("/api/plugin/login", {
        email = email,
        login = email,
        password = password,
        hwid = account.hwid
    })

    if not payload.ok then
        return { success = false, status = status, error = payload.message or "Giris basarisiz." }
    end
    local user = store_user(account, payload.user)
    return { success = true, user = user, hwid = account.hwid, message = payload.message or "Giris basarili." }
end

function auth.save_session(user, message)
    local account = read_account()
    if type(user) ~= "table" then
        return { success = false, error = "Site hesabi okunamadi." }
    end
    local saved = store_user(account, user)
    if not saved.token or saved.token == "" then
        return { success = false, error = "Site hesabi token dondurmedi." }
    end
    return {
        success = true,
        authenticated = true,
        user = saved,
        hwid = account.hwid or "",
        message = message or "Giris basarili."
    }
end

function auth.logout()
    local account = read_account()
    account.id = nil
    account.username = ""
    account.email = ""
    account.role = "user"
    account.token = ""
    account.token_protected = false
    account.license_until = ""
    account.daily_limit = 0
    account.allowed_appids = {}
    account.approval_status = "approved"
    account.remote_blocked = false
    account.remote_block_message = ""
    account.updated_at = now()
    write_account(account)
    CONTROL_CACHE.value = nil
    CONTROL_CACHE.expires_at = 0
    return { success = true, message = "Cikis yapildi.", hwid = account.hwid or "" }
end

local function account_payload(account, extra)
    local payload = {
        token = account.token or "",
        email = account.email or "",
        hwid = account.hwid or "",
        version = PLUGIN_VERSION
    }
    if type(extra) == "table" then
        for key, value in pairs(extra) do payload[key] = value end
    end
    return payload
end

local function disabled_source_match(disabled_sources, api_name)
    local clean = tostring(api_name or ""):lower()
    if clean == "" or type(disabled_sources) ~= "table" then return false end
    for _, item in ipairs(disabled_sources) do
        local name = tostring(type(item) == "table" and item.name or item):lower()
        if name ~= "" and name == clean then return true end
    end
    return false
end

local function appid_allowed(allowed_appids, appid)
    local clean_appid = tostring(appid or ""):match("%d+") or ""
    if clean_appid == "" then return true end
    if type(allowed_appids) == "table" then
        local has_restriction = false
        for _, value in ipairs(allowed_appids) do
            local clean = tostring(value or ""):match("%d+") or ""
            if clean ~= "" then
                has_restriction = true
                if clean == clean_appid then return true end
            end
        end
        return not has_restriction
    end
    local text = tostring(allowed_appids or "")
    if text == "" then return true end
    local has_restriction = false
    for clean in text:gmatch("%d+") do
        has_restriction = true
        if clean == clean_appid then return true end
    end
    return not has_restriction
end

local function license_active(account)
    local value = tostring((account and account.license_until) or "")
    if value == "" then return true end
    local y, m, d = value:match("^(%d%d%d%d)%-(%d%d)%-(%d%d)")
    if not y then return true end
    local expires = os.time({ year = tonumber(y), month = tonumber(m), day = tonumber(d), hour = 23, min = 59, sec = 59 })
    if not expires then return true end
    return os.time() <= expires
end

local function registered_game_count_for_limit(current_appid)
    local clean_current = tostring(current_appid or ""):match("%d+") or ""
    local ok, games = pcall(game_registry.list_registered_games)
    if not ok or type(games) ~= "table" then return 0, false end
    local count = 0
    local already_registered = false
    local seen = {}
    for _, game in ipairs(games) do
        local clean = tostring(type(game) == "table" and game.appid or ""):match("%d+") or ""
        if clean ~= "" and not seen[clean] then
            seen[clean] = true
            count = count + 1
            if clean_current ~= "" and clean == clean_current then already_registered = true end
        end
    end
    return count, already_registered
end

local function local_game_limit(account, status_result)
    local limit = tonumber(status_result and status_result.game_limit or 0) or 0
    if limit <= 0 then limit = tonumber(status_result and status_result.limit or 0) or 0 end
    if limit <= 0 then limit = tonumber(status_result and status_result.daily_limit or 0) or 0 end
    if limit <= 0 then limit = tonumber(account and account.game_limit or 0) or 0 end
    if limit <= 0 then limit = tonumber(account and account.limit or 0) or 0 end
    if limit <= 0 then limit = tonumber(account and account.daily_limit or 0) or 0 end
    return math.floor(limit)
end

local function compare_versions(a, b)
    local left = utils.parse_version(a)
    local right = utils.parse_version(b)
    local length = math.max(#left, #right)
    for index = 1, length do
        local av = tonumber(left[index] or 0) or 0
        local bv = tonumber(right[index] or 0) or 0
        if av < bv then return -1 end
        if av > bv then return 1 end
    end
    return 0
end

function auth.apply_browser_control(payload)
    if type(payload) ~= "table" or payload.ok == false then return false end
    local control = type(payload.control) == "table" and payload.control or {}
    local result = {
        success = true,
        authenticated = payload.authenticated ~= false,
        control = control,
        can_add_games = payload.can_add_games ~= false,
        blocked = payload.blocked == true,
        disabled_sources = type(payload.disabled_sources) == "table" and payload.disabled_sources or {},
        source_scores = type(payload.source_scores) == "table" and payload.source_scores or {},
        message = tostring(payload.message or "OK"),
        synced_at = now()
    }
    CONTROL_CACHE.value = result
    CONTROL_CACHE.expires_at = os.time() + 180
    utils.write_json(CONTROL_CACHE_FILE, result)
    return true
end

function auth.apply_browser_account_status(payload)
    if type(payload) ~= "table" then return false end
    local account = read_account()
    if payload.authenticated == false and (tonumber(payload.status or 0) == 401 or payload.force_logout == true or payload.session_revoked == true) then
        auth.logout()
        return true
    end
    account.remote_blocked = payload.blocked == true
    account.remote_block_message = tostring(payload.message or payload.error or "")
    local user = type(payload.user) == "table" and payload.user or {}
    account.license_until = payload.license_until or user.license_until or account.license_until or ""
    account.daily_limit = payload.daily_limit or user.daily_limit or account.daily_limit or 0
    account.game_limit = payload.game_limit or payload.limit or user.game_limit or user.limit or account.game_limit or 0
    account.allowed_appids = payload.allowed_appids or user.allowed_appids or account.allowed_appids or {}
    account.approval_status = payload.approval_status or user.approval_status or account.approval_status or "approved"
    account.daily_add_count = payload.daily_add_count or account.daily_add_count or 0
    account.updated_at = now()
    write_account(account)
    return true
end

function auth.control()
    local account = read_account()
    if not account.token or account.token == "" then
        return { success = false, authenticated = false, error = "Once SecurityShoop hesabina giris yap." }
    end
    if CONTROL_CACHE.value and os.time() < tonumber(CONTROL_CACHE.expires_at or 0) then
        return CONTROL_CACHE.value
    end
    local saved_control = utils.read_json(CONTROL_CACHE_FILE)
    if type(saved_control) == "table" and saved_control.success == true then
        CONTROL_CACHE.value = saved_control
        CONTROL_CACHE.expires_at = os.time() + 30
        return saved_control
    end
    local payload, status = post_json("/api/plugin/control", account_payload(account), 6)
    if payload.ok then
        local result = {
            success = true,
            authenticated = true,
            control = payload.control or {},
            can_add_games = payload.can_add_games ~= false,
            blocked = payload.blocked == true,
            disabled_sources = payload.disabled_sources or {},
            source_scores = payload.source_scores or {},
            message = payload.message or "OK"
        }
        CONTROL_CACHE.value = result
        CONTROL_CACHE.expires_at = os.time() + 30
        return result
    end
    if payload.site_unavailable then
        local result = { success = true, authenticated = true, offline = true, can_add_games = true, disabled_sources = {}, source_scores = {}, message = payload.message or "Site gecici olarak ulasilamiyor." }
        CONTROL_CACHE.value = result
        CONTROL_CACHE.expires_at = os.time() + 10
        return result
    end
    return { success = false, authenticated = true, status = status, error = payload.message or "Plugin kontrolu alinamadi." }
end

function auth.source_priority(api_name)
    local control = auth.control()
    if not control or type(control.source_scores) ~= "table" then return 500 end
    local clean = tostring(api_name or ""):lower()
    for _, item in ipairs(control.source_scores) do
        local name = tostring(type(item) == "table" and item.name or ""):lower()
        if name ~= "" and name == clean then
            return tonumber(item.priority or (100 - tonumber(item.score or 0))) or 500
        end
    end
    return 500
end

function auth.account_status(appid)
    local account = read_account()
    if not account.token or account.token == "" then
        return { success = false, authenticated = false, error = "Once SecurityShoop hesabina giris yap." }
    end
    if account.remote_blocked == true then
        return { success = false, authenticated = true, blocked = true, status = 403, error = account.remote_block_message ~= "" and account.remote_block_message or "Bu hesap veya cihaz uzaktan engellendi." }
    end
    local payload, status = post_json("/api/plugin/account-status", account_payload(account, {
        appid = tostring(appid or "")
    }), 6)
    if payload.ok then
        account.license_until = payload.license_until or (payload.user and payload.user.license_until) or account.license_until or ""
        account.daily_limit = payload.daily_limit or (payload.user and payload.user.daily_limit) or account.daily_limit or 0
        account.allowed_appids = payload.allowed_appids or account.allowed_appids or {}
        account.updated_at = now()
        write_account(account)
        return {
            success = true,
            authenticated = true,
            user = public_user({
                id = account.id,
                username = account.username,
                email = account.email,
                role = account.role,
                license_until = account.license_until,
                daily_limit = account.daily_limit,
                allowed_appids = account.allowed_appids
            }),
            hwid = account.hwid or "",
            daily_add_count = payload.daily_add_count or 0,
            daily_limit = payload.daily_limit or account.daily_limit or 0,
            allowed_appids = payload.allowed_appids or account.allowed_appids or {},
            license_until = payload.license_until or account.license_until or "",
            license_active = payload.license_active ~= false
        }
    end
    if payload.site_unavailable then
        return {
            success = true,
            authenticated = true,
            offline = true,
            user = public_user(account),
            hwid = account.hwid or "",
            daily_add_count = 0,
            daily_limit = account.daily_limit or 0,
            allowed_appids = account.allowed_appids or {},
            license_until = account.license_until or "",
            message = payload.message or "Site gecici olarak ulasilamiyor."
        }
    end
    return { success = false, authenticated = true, status = status, error = payload.message or "Hesap kontrolu basarisiz." }
end

function auth.ensure_can_add(appid, api_name)
    local account = read_account()
    if not account.token or account.token == "" then
        return false, "Once SecurityShoop hesabina giris yap.", 401
    end
    if account.remote_blocked == true then
        return false, account.remote_block_message ~= "" and account.remote_block_message or "Bu hesap veya cihaz uzaktan engellendi.", 403
    end
    if not license_active(account) then
        return false, "Lisans suresi doldu. Yeni lisans al veya admin panelden lisansi yenile.", 403
    end
    local control = auth.control()
    if control and control.success == false then
        return false, control.error or "Plugin kontrolu basarisiz.", control.status or 0
    end
    if control and control.can_add_games == false then
        return false, control.message or "Oyun ekleme gecici olarak kapali.", 403
    end
    local control_values = control and control.control or {}
    if control_values.force_update == true and tostring(control_values.latest_version or "") ~= "" and compare_versions(PLUGIN_VERSION, control_values.latest_version) < 0 then
        return false, "Plugin guncellemesi zorunlu. Surum " .. tostring(control_values.latest_version) .. " kurulmadan oyun eklenemez.", 426
    end
    if control and disabled_source_match(control.disabled_sources, api_name) then
        return false, "Bu kaynak 3 kere hata verdigi icin sitede gecici olarak pasife alindi.", 423
    end
    local status_result = auth.account_status(appid)
    if status_result and status_result.success == false then
        return false, status_result.error or "Hesap kontrolu basarisiz.", status_result.status or 0
    end
    local allowed_appids = status_result and status_result.allowed_appids or account.allowed_appids
    if not appid_allowed(allowed_appids, appid) then
        return false, "Bu hesap sadece izin verilen AppID listesindeki oyunlari ekleyebilir.", 403
    end
    local limit = local_game_limit(account, status_result)
    if limit > 0 then
        local current_count, already_registered = registered_game_count_for_limit(appid)
        if not already_registered and current_count >= limit then
            return false, "Bu lisans en fazla " .. tostring(limit) .. " oyun ekleyebilir. Admin panelden paketi yukselt veya izinli AppID listesini degistir.", 403
        end
    end
    return true
end

function auth.heartbeat(status, appid, api_name, message, source_health, installed_games)
    local account = read_account()
    if not account.token or account.token == "" then
        return { success = true, authenticated = false, status = { local_only = true }, commands = {}, message = "" }
    end
    local payload, http_status = post_json("/api/plugin/heartbeat", account_payload(account, {
        status = status or "online",
        appid = tostring(appid or ""),
        current_api = tostring(api_name or ""),
        message = tostring(message or ""),
        source_health = type(source_health) == "table" and source_health or nil,
        installed_games = type(installed_games) == "table" and installed_games or nil
    }), 8)
    if payload.ok then
        return {
            success = true,
            authenticated = payload.authenticated ~= false,
            status = payload.status or { local_only = payload.authenticated == false },
            commands = payload.commands or {},
            message = payload.message or "Plugin durumu siteye gonderildi."
        }
    end
    if payload.site_unavailable then
        return { success = true, authenticated = true, offline = true, status = { local_only = true }, commands = {}, message = payload.message or "Site gecici olarak ulasilamiyor." }
    end
    return { success = false, authenticated = true, status_code = http_status, error = payload.message or "Plugin durumu gonderilemedi." }
end

function auth.log_action(action, details)
    local account = read_account()
    if not account.token or account.token == "" then return false end
    local payload = post_json("/api/log-action", account_payload(account, {
        action = tostring(action or ""),
        details = tostring(details or "")
    }), 8)
    return payload and payload.ok == true
end

function auth.ack_command(command_id, ok_value, result, status)
    local account = read_account()
    if not account.token or account.token == "" then return false end
    local payload = post_json("/api/plugin/commands/" .. tostring(command_id or "") .. "/ack", account_payload(account, {
        ok = ok_value ~= false,
        result = tostring(result or ""),
        status = tostring(status or "")
    }), 8)
    return payload and payload.ok == true
end

function auth.report_error(message, context, severity, page_url)
    local account = read_account()
    if not account.token or account.token == "" then
        return { success = false, authenticated = false, error = "Hata raporu icin once SecurityShoop hesabina giris yap." }
    end
    local payload, status = post_json("/api/plugin/error-report", account_payload(account, {
        message = tostring(message or ""),
        context = tostring(context or ""),
        severity = tostring(severity or "normal"),
        page_url = tostring(page_url or "")
    }), 10)
    if payload.ok then return { success = true, message = payload.message or "Hata raporu gonderildi.", report = payload.report } end
    return { success = false, status = status, error = payload.message or "Hata raporu gonderilemedi." }
end

function auth.notifications()
    local account = read_account()
    if not account.token or account.token == "" then
        return { success = false, authenticated = false, error = "Bildirimler icin once SecurityShoop hesabina giris yap." }
    end
    local payload, status = post_json("/api/plugin/notifications", account_payload(account), 8)
    if payload.ok then
        return { success = true, authenticated = true, notifications = payload.notifications or {}, count = payload.count or 0 }
    end
    if payload.site_unavailable then
        return { success = true, authenticated = true, offline = true, notifications = {}, count = 0, message = payload.message or "Site gecici olarak ulasilamiyor." }
    end
    return { success = false, status = status, error = payload.message or "Bildirimler alinamadi." }
end

return auth


