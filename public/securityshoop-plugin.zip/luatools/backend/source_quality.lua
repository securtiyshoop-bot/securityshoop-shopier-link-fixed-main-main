local http_client = require("http_client")
local paths = require("paths")
local utils = require("plugin_utils")

local quality = {}
local METRICS_FILE = paths.backend_path("data/source-quality.json")

local function read_metrics()
    local data = utils.read_json(METRICS_FILE)
    if type(data) ~= "table" then data = {} end
    if type(data.sources) ~= "table" then data.sources = {} end
    return data
end

function quality.record(name, latency_ms, speed_kbps, success)
    name = tostring(name or "")
    if name == "" then return end
    local data = read_metrics()
    local current = type(data.sources[name]) == "table" and data.sources[name] or {}
    local samples = math.min(20, (tonumber(current.samples or 0) or 0) + 1)
    local weight = samples <= 1 and 1 or 0.35
    local latency = math.max(0, tonumber(latency_ms or 0) or 0)
    local speed = math.max(0, tonumber(speed_kbps or 0) or 0)
    current.latency_ms = samples <= 1 and latency or math.floor((tonumber(current.latency_ms or latency) * (1 - weight)) + (latency * weight))
    current.speed_kbps = samples <= 1 and speed or math.floor((tonumber(current.speed_kbps or speed) * (1 - weight)) + (speed * weight))
    current.samples = samples
    current.failures = success == false and math.min(10, (tonumber(current.failures or 0) or 0) + 1) or math.max(0, (tonumber(current.failures or 0) or 0) - 1)
    current.last_success = success ~= false
    current.updated_at = os.date("!%Y-%m-%dT%H:%M:%SZ")
    data.sources[name] = current
    data.updated_at = current.updated_at
    utils.write_json(METRICS_FILE, data)
end

function quality.score(name, remote_priority)
    local data = read_metrics()
    local current = data.sources[tostring(name or "")] or {}
    local priority = tonumber(remote_priority or 500) or 500
    local latency = tonumber(current.latency_ms or 1500) or 1500
    local speed = tonumber(current.speed_kbps or 0) or 0
    local failures = tonumber(current.failures or 0) or 0
    return math.floor((priority * 10) + latency + (failures * 1200) - math.min(2500, speed / 20))
end

function quality.get(name)
    return read_metrics().sources[tostring(name or "")] or {}
end

function quality.probe(name, url, user_agent, timeout_seconds)
    local started_at = os.time()
    local ok, response = pcall(http_client.head, tostring(url or ""), {
        timeout = math.max(2, math.min(15, tonumber(timeout_seconds or 5) or 5)),
        headers = {
            ["Accept"] = "application/zip,application/octet-stream,*/*",
            ["User-Agent"] = tostring(user_agent or "SecurityShoop")
        }
    })
    -- os.time() saniye hassasiyetlidir; 0 gelirse istek < 1 saniye surdugu anlamina gelir
    local raw_seconds = os.time() - started_at
    local latency_ms = raw_seconds > 0 and (raw_seconds * 1000) or 300
    local status = ok and type(response) == "table" and tonumber(response.status or response.status_code or 0) or 0
    local success = ok and (status == 200 or status == 206)
    local result = {
        success = success,
        status = status,
        latencyMs = latency_ms,
        speedKbps = 0,
        bytes = 0,
        error = success and "" or (ok and ("HTTP " .. tostring(status)) or tostring(response or "Kaynak istegi basarisiz."))
    }
    quality.record(name, result.latencyMs, result.speedKbps, result.success == true)
    return result
end

return quality
