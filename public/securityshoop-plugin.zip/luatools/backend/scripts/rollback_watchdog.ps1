param([Parameter(Mandatory = $true)][string]$PendingFile)

$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $PendingFile)) { exit 0 }
$pending = Get-Content -Raw -LiteralPath $PendingFile | ConvertFrom-Json
$oldPid = [int]$pending.oldSteamPid
$newSteam = $null
$restartDeadline = (Get-Date).AddMinutes(10)
do {
    Start-Sleep -Seconds 2
    $newSteam = Get-Process steam -ErrorAction SilentlyContinue | Where-Object { $_.Id -ne $oldPid } | Select-Object -First 1
} while (-not $newSteam -and (Get-Date) -lt $restartDeadline)
if (-not $newSteam) { exit 0 }

$healthDeadline = (Get-Date).AddSeconds(120)
do {
    Start-Sleep -Seconds 2
    if (Test-Path -LiteralPath ([string]$pending.healthFile)) {
        Remove-Item -LiteralPath $PendingFile -Force -ErrorAction SilentlyContinue
        exit 0
    }
} while ((Get-Date) -lt $healthDeadline)

$pluginDir = [IO.Path]::GetFullPath([string]$pending.pluginDir)
$pluginParent = [IO.Path]::GetFullPath([string]$pending.pluginParent).TrimEnd('\') + '\'
$backupDir = [IO.Path]::GetFullPath([string]$pending.backupDir)
if (-not $pluginDir.StartsWith($pluginParent, [StringComparison]::OrdinalIgnoreCase)) { exit 2 }
if (-not (Test-Path -LiteralPath $backupDir)) { exit 3 }
Get-Process steam,steamwebhelper -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
if (Test-Path -LiteralPath $pluginDir) { Remove-Item -LiteralPath $pluginDir -Recurse -Force }
Copy-Item -LiteralPath $backupDir -Destination $pluginDir -Recurse -Force
Remove-Item -LiteralPath $PendingFile -Force -ErrorAction SilentlyContinue
$steamPath = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -Name SteamPath -ErrorAction SilentlyContinue).SteamPath
if ($steamPath -and (Test-Path -LiteralPath (Join-Path $steamPath 'steam.exe'))) {
    Start-Process -FilePath (Join-Path $steamPath 'steam.exe') -ArgumentList '-clearbeta' -WindowStyle Hidden
}
