param(
    [Parameter(Mandatory = $true)][string]$RequestFile
)

$ErrorActionPreference = 'Stop'
$request = Get-Content -Raw -LiteralPath $RequestFile | ConvertFrom-Json
$stateFile = [string]$request.stateFile
$zipPath = [string]$request.zipPath
$cancelFile = [string]$request.cancelFile
$launcherFile = [string]$request.launcherFile
$client = $null
$response = $null
$inputStream = $null
$outputStream = $null
$zip = $null

function Update-State([hashtable]$Values) {
    $json = $Values | ConvertTo-Json -Compress -Depth 5
    $temp = $stateFile + '.tmp'
    [System.IO.File]::WriteAllText($temp, $json, [System.Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $temp -Destination $stateFile -Force
}

function Assert-NotCancelled {
    if (Test-Path -LiteralPath $cancelFile) {
        throw [System.OperationCanceledException]::new('Fix indirme kullanici tarafindan iptal edildi.')
    }
}

try {
    $uri = [System.Uri]::new([string]$request.url)
    if (-not $uri.IsAbsoluteUri -or $uri.Scheme -ne 'https') { throw 'Fix URL must use HTTPS.' }

    $installPath = [System.IO.Path]::GetFullPath([string]$request.installPath)
    if (-not [System.IO.Directory]::Exists($installPath)) { throw 'Game install directory was not found.' }
    $installRoot = $installPath.TrimEnd('\', '/') + [System.IO.Path]::DirectorySeparatorChar
    $zipDirectory = [System.IO.Path]::GetDirectoryName([System.IO.Path]::GetFullPath($zipPath))
    if (-not [System.IO.Directory]::Exists($zipDirectory)) {
        [System.IO.Directory]::CreateDirectory($zipDirectory) | Out-Null
    }

    Remove-Item -LiteralPath $cancelFile -Force -ErrorAction SilentlyContinue
    Add-Type -AssemblyName System.Net.Http
    $client = [System.Net.Http.HttpClient]::new()
    $client.Timeout = [System.TimeSpan]::FromMinutes(30)
    if (-not [string]::IsNullOrWhiteSpace([string]$request.userAgent)) {
        $client.DefaultRequestHeaders.TryAddWithoutValidation('User-Agent', [string]$request.userAgent) | Out-Null
    }

    $response = $client.GetAsync($uri, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
    $response.EnsureSuccessStatusCode()
    $totalBytes = if ($response.Content.Headers.ContentLength) { [int64]$response.Content.Headers.ContentLength } else { [int64]0 }
    $inputStream = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
    $outputStream = [System.IO.File]::Open($zipPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
    $buffer = [byte[]]::new(65536)
    $bytesRead = [int64]0
    $lastStateUpdate = [DateTime]::UtcNow.AddSeconds(-2)

    while (($count = $inputStream.Read($buffer, 0, $buffer.Length)) -gt 0) {
        Assert-NotCancelled
        $outputStream.Write($buffer, 0, $count)
        $bytesRead += $count
        if (([DateTime]::UtcNow - $lastStateUpdate).TotalMilliseconds -ge 400) {
            Update-State @{ status = 'downloading'; bytesRead = $bytesRead; totalBytes = $totalBytes }
            $lastStateUpdate = [DateTime]::UtcNow
        }
    }
    $outputStream.Dispose()
    $outputStream = $null
    $inputStream.Dispose()
    $inputStream = $null
    Assert-NotCancelled

    $fileInfo = Get-Item -LiteralPath $zipPath
    if ($fileInfo.Length -lt 22) { throw 'Downloaded fix package is empty or truncated.' }
    $sha256 = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
    $fileEntries = @($zip.Entries | Where-Object { $_.Name -ne '' })
    if ($fileEntries.Count -eq 0) { throw 'Corrupted zip: fix package has no files.' }
    Update-State @{ status = 'extracting'; filesDone = 0; totalFiles = $fileEntries.Count; sha256 = $sha256; bytes = [int64]$fileInfo.Length }

    $filesDone = 0
    foreach ($entry in $zip.Entries) {
        Assert-NotCancelled
        $relativeName = $entry.FullName.Replace('/', [System.IO.Path]::DirectorySeparatorChar)
        $target = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($installPath, $relativeName))
        if (-not $target.StartsWith($installRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw 'Unsafe zip path was blocked.'
        }
        if ($entry.Name -eq '') {
            [System.IO.Directory]::CreateDirectory($target) | Out-Null
            continue
        }
        $targetDirectory = [System.IO.Path]::GetDirectoryName($target)
        if (-not [System.IO.Directory]::Exists($targetDirectory)) {
            [System.IO.Directory]::CreateDirectory($targetDirectory) | Out-Null
        }
        [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $target, $true)
        $filesDone++
        Update-State @{ status = 'extracting'; filesDone = $filesDone; totalFiles = $fileEntries.Count; sha256 = $sha256; bytes = [int64]$fileInfo.Length }
    }

    Update-State @{ status = 'done'; success = $true; files = $filesDone; sha256 = $sha256; bytes = [int64]$fileInfo.Length }
}
catch {
    $cancelled = $_.Exception -is [System.OperationCanceledException] -or (Test-Path -LiteralPath $cancelFile)
    $status = if ($cancelled) { 'cancelled' } else { 'failed' }
    Update-State @{ status = $status; success = $false; error = $_.Exception.Message }
}
finally {
    if ($null -ne $zip) { $zip.Dispose() }
    if ($null -ne $outputStream) { $outputStream.Dispose() }
    if ($null -ne $inputStream) { $inputStream.Dispose() }
    if ($null -ne $response) { $response.Dispose() }
    if ($null -ne $client) { $client.Dispose() }
    if ((Test-Path -LiteralPath $stateFile) -and ((Get-Content -Raw -LiteralPath $stateFile) -match '"status":"(failed|cancelled)"')) {
        Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue
    }
    Remove-Item -LiteralPath $cancelFile -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $RequestFile -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $launcherFile -Force -ErrorAction SilentlyContinue
}
