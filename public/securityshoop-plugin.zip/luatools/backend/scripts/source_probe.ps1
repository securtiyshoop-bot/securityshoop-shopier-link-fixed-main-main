param(
    [Parameter(Mandatory = $true)][string]$RequestFile,
    [Parameter(Mandatory = $true)][string]$OutputFile
)

$ErrorActionPreference = 'Stop'
$request = Get-Content -Raw -LiteralPath $RequestFile | ConvertFrom-Json
$client = $null
$response = $null
$stream = $null

function Write-Result([hashtable]$Values) {
    [System.IO.File]::WriteAllText($OutputFile, ($Values | ConvertTo-Json -Compress -Depth 4), [System.Text.UTF8Encoding]::new($false))
}

try {
    $uri = [System.Uri]::new([string]$request.url)
    if (-not $uri.IsAbsoluteUri -or @('https', 'http') -notcontains $uri.Scheme) { throw 'Invalid source URL.' }
    Add-Type -AssemblyName System.Net.Http
    $client = [System.Net.Http.HttpClient]::new()
    $client.Timeout = [TimeSpan]::FromSeconds([Math]::Max(2, [Math]::Min(15, [int]$request.timeoutSeconds)))
    $client.DefaultRequestHeaders.TryAddWithoutValidation('User-Agent', [string]$request.userAgent) | Out-Null
    $message = [System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::Get, $uri)
    $message.Headers.Range = [System.Net.Http.Headers.RangeHeaderValue]::new(0, 65535)
    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    $response = $client.SendAsync($message, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
    $latencyMs = [Math]::Max(1, $watch.ElapsedMilliseconds)
    if (-not $response.IsSuccessStatusCode -and [int]$response.StatusCode -ne 206) { throw "HTTP $([int]$response.StatusCode)" }
    $stream = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
    $buffer = [byte[]]::new(16384)
    $bytes = [int64]0
    while ($bytes -lt 65536 -and ($read = $stream.Read($buffer, 0, [Math]::Min($buffer.Length, 65536 - $bytes))) -gt 0) {
        $bytes += $read
    }
    $watch.Stop()
    $elapsedMs = [Math]::Max(1, $watch.ElapsedMilliseconds)
    $speedKbps = [Math]::Round((($bytes * 8.0) / 1000.0) / ($elapsedMs / 1000.0), 2)
    Write-Result @{ success = $true; status = [int]$response.StatusCode; latencyMs = $latencyMs; speedKbps = $speedKbps; bytes = $bytes; elapsedMs = $elapsedMs }
}
catch {
    Write-Result @{ success = $false; status = 0; latencyMs = 15000; speedKbps = 0; error = $_.Exception.Message }
}
finally {
    if ($null -ne $stream) { $stream.Dispose() }
    if ($null -ne $response) { $response.Dispose() }
    if ($null -ne $client) { $client.Dispose() }
    Remove-Item -LiteralPath $RequestFile -Force -ErrorAction SilentlyContinue
}
