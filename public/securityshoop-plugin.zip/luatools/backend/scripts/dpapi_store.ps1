param(
    [Parameter(Mandatory = $true)][ValidateSet('protect', 'unprotect')][string]$Operation,
    [Parameter(Mandatory = $true)][string]$InputFile,
    [Parameter(Mandatory = $true)][string]$OutputFile
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Security
$entropy = [System.Text.Encoding]::UTF8.GetBytes('SecurityShoop/AccountToken/v1')

try {
    if ($Operation -eq 'protect') {
        $plainText = [System.IO.File]::ReadAllText($InputFile, [System.Text.Encoding]::UTF8)
        if ([string]::IsNullOrWhiteSpace($plainText)) { throw 'Token is empty.' }
        $plainBytes = [System.Text.Encoding]::UTF8.GetBytes($plainText)
        $protected = [System.Security.Cryptography.ProtectedData]::Protect(
            $plainBytes,
            $entropy,
            [System.Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        [System.IO.File]::WriteAllBytes($OutputFile, $protected)
        [Array]::Clear($plainBytes, 0, $plainBytes.Length)
    }
    else {
        $protected = [System.IO.File]::ReadAllBytes($InputFile)
        $plainBytes = [System.Security.Cryptography.ProtectedData]::Unprotect(
            $protected,
            $entropy,
            [System.Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        [System.IO.File]::WriteAllText($OutputFile, [System.Text.Encoding]::UTF8.GetString($plainBytes), [System.Text.UTF8Encoding]::new($false))
        [Array]::Clear($plainBytes, 0, $plainBytes.Length)
    }
}
finally {
    if ($Operation -eq 'protect') {
        Remove-Item -LiteralPath $InputFile -Force -ErrorAction SilentlyContinue
    }
}
