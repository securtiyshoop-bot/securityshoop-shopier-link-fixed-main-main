param([Parameter(Mandatory = $true)][string]$RequestFile)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$request = Get-Content -Raw -LiteralPath $RequestFile | ConvertFrom-Json
$pluginDir = [IO.Path]::GetFullPath([string]$request.pluginDir)
$pluginParent = [IO.Path]::GetFullPath([IO.Path]::GetDirectoryName($pluginDir)).TrimEnd('\') + '\'
if (-not $pluginDir.StartsWith($pluginParent, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe plugin path.' }
$rollbackRoot = if ([string]::IsNullOrWhiteSpace([string]$request.rollbackRoot)) { Join-Path $env:LOCALAPPDATA 'SecurityShoop\rollback' } else { [IO.Path]::GetFullPath([string]$request.rollbackRoot) }
$backupDir = Join-Path $rollbackRoot 'previous'
$pendingFile = Join-Path $rollbackRoot 'pending.json'
$workDir = Join-Path $env:TEMP ('securityshoop-update-' + [guid]::NewGuid().ToString('N'))
$zipPath = Join-Path $workDir 'plugin.zip'
$stagingDir = Join-Path $workDir 'staging'

function Write-State([hashtable]$value) {
    [IO.File]::WriteAllText([string]$request.stateFile, ($value | ConvertTo-Json -Compress -Depth 5), [Text.UTF8Encoding]::new($false))
}

try {
    New-Item -ItemType Directory -Path $workDir,$stagingDir,$rollbackRoot -Force | Out-Null
    Write-State @{ status = 'downloading'; version = [string]$request.latestVersion }
    Invoke-WebRequest -UseBasicParsing -Uri ([string]$request.url) -OutFile $zipPath -Headers @{ 'User-Agent' = 'SecurityShoop-Signed-Updater' }
    $actualHash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualHash -ne ([string]$request.expectedSha256).ToLowerInvariant()) { throw 'Signed update SHA-256 mismatch.' }

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [IO.Compression.ZipFile]::OpenRead($zipPath)
    try {
        if ($zip.Entries.Count -eq 0) { throw 'Update ZIP is empty.' }
        $root = [IO.Path]::GetFullPath($stagingDir).TrimEnd('\') + '\'
        foreach ($entry in $zip.Entries) {
            $target = [IO.Path]::GetFullPath([IO.Path]::Combine($stagingDir, $entry.FullName))
            if (-not $target.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe update ZIP path.' }
            if ($entry.Name -eq '') { [IO.Directory]::CreateDirectory($target) | Out-Null; continue }
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
            [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $target, $true)
        }
    } finally { $zip.Dispose() }
    foreach ($required in @('plugin.json','backend\main.lua','public\luatools.js')) {
        if (-not (Test-Path -LiteralPath (Join-Path $stagingDir $required))) { throw "Update missing $required" }
    }

    $backupFull = [IO.Path]::GetFullPath($backupDir)
    $rollbackFull = [IO.Path]::GetFullPath($rollbackRoot).TrimEnd('\') + '\'
    if (-not $backupFull.StartsWith($rollbackFull, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe rollback path.' }
    if (Test-Path -LiteralPath $backupDir) { Remove-Item -LiteralPath $backupDir -Recurse -Force }
    Copy-Item -LiteralPath $pluginDir -Destination $backupDir -Recurse -Force
    Copy-Item -Path (Join-Path $stagingDir '*') -Destination $pluginDir -Recurse -Force
    Remove-Item -LiteralPath ([string]$request.healthFile) -Force -ErrorAction SilentlyContinue
    $steam = Get-Process steam -ErrorAction SilentlyContinue | Select-Object -First 1
    $pending = @{
        pluginDir = $pluginDir
        pluginParent = $pluginParent
        backupDir = $backupDir
        healthFile = [string]$request.healthFile
        appliedAt = [DateTime]::UtcNow.ToString('o')
        oldSteamPid = if ($steam) { $steam.Id } else { 0 }
        oldVersion = [string]$request.currentVersion
        newVersion = [string]$request.latestVersion
    }
    [IO.File]::WriteAllText($pendingFile, ($pending | ConvertTo-Json -Compress -Depth 5), [Text.UTF8Encoding]::new($false))
    Write-State @{ status = 'ready'; verified = $true; sha256 = $actualHash; version = [string]$request.latestVersion }
}
catch {
    Write-State @{ status = 'failed'; error = $_.Exception.Message; version = [string]$request.latestVersion }
}
finally {
    Remove-Item -LiteralPath $RequestFile -Force -ErrorAction SilentlyContinue
    $fullWork = [IO.Path]::GetFullPath($workDir)
    $tempRoot = [IO.Path]::GetFullPath($env:TEMP).TrimEnd('\') + '\'
    if ($fullWork.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $fullWork)) {
        Remove-Item -LiteralPath $fullWork -Recurse -Force
    }
}
