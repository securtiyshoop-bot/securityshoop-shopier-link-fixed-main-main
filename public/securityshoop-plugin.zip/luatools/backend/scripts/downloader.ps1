param(
    [string]$Url,
    [Parameter(Mandatory = $true)][string]$DestPath,
    [Parameter(Mandatory = $true)][string]$ExtractDir,
    [string]$StateFile,
    [string]$UserAgent = "discord(dot)gg/luatools"
)

$ErrorActionPreference = 'Stop'

function Update-State([hashtable]$Values) {
    if ([string]::IsNullOrWhiteSpace($StateFile)) { return }
    $json = $Values | ConvertTo-Json -Compress -Depth 4
    $temp = $StateFile + '.tmp'
    [System.IO.File]::WriteAllText($temp, $json, (New-Object System.Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $temp -Destination $StateFile -Force
}

try {
    $downloadWatch = [System.Diagnostics.Stopwatch]::StartNew()
    if (-not [string]::IsNullOrWhiteSpace($Url)) {
        Update-State @{ status = 'downloading' }
        Invoke-WebRequest -Uri $Url -OutFile $DestPath -UserAgent $UserAgent -UseBasicParsing
    }

    if (-not (Test-Path -LiteralPath $DestPath)) { throw 'Downloaded package was not created.' }
    $fileInfo = Get-Item -LiteralPath $DestPath
    if ($fileInfo.Length -lt 22) { throw 'Downloaded package is empty or truncated.' }
    $sha256 = (Get-FileHash -LiteralPath $DestPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $bytes = [int64]$fileInfo.Length
    $downloadWatch.Stop()
    $elapsedMs = [Math]::Max(1, $downloadWatch.ElapsedMilliseconds)
    $speedKbps = [Math]::Round((($bytes * 8.0) / 1000.0) / ($elapsedMs / 1000.0), 2)
    
    if (-not [string]::IsNullOrWhiteSpace($ExtractDir)) {
        Update-State @{ status = 'extracting'; sha256 = $sha256; bytes = $bytes }
        if (-not (Test-Path $ExtractDir)) { New-Item -ItemType Directory -Force -Path $ExtractDir | Out-Null }
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip = $null
        try {
            $zip = [System.IO.Compression.ZipFile]::OpenRead($DestPath)
            if ($zip.Entries.Count -eq 0) { throw 'Corrupted zip: package has no entries.' }
            $root = [System.IO.Path]::GetFullPath($ExtractDir).TrimEnd('\') + '\'
            $luaCount = 0
            foreach ($entry in $zip.Entries) {
                $target = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($ExtractDir, $entry.FullName))
                if (-not $target.StartsWith($root, [System.StringComparison]::OrdinalIgnoreCase)) {
                    throw 'Unsafe zip path was blocked.'
                }
                $dir = [System.IO.Path]::GetDirectoryName($target)
                if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
                if ($entry.Name -ne '') {
                    [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $target, $true)
                    if ($entry.Name -match '^\d+\.lua$') { $luaCount++ }
                }
            }
            if ($luaCount -eq 0) { throw 'Package does not contain an AppID Lua file.' }
        }
        finally {
            if ($null -ne $zip) { $zip.Dispose() }
        }
        Update-State @{ status = 'extracted'; sha256 = $sha256; bytes = $bytes; elapsedMs = $elapsedMs; speedKbps = $speedKbps; verified = $true }
    }
    else {
        Update-State @{ status = 'done'; sha256 = $sha256; bytes = $bytes; elapsedMs = $elapsedMs; speedKbps = $speedKbps; verified = $true }
    }
}
catch {
    try {
        if (-not [string]::IsNullOrWhiteSpace($ExtractDir) -and -not (Test-Path -LiteralPath $ExtractDir)) {
            New-Item -ItemType Directory -Force -Path $ExtractDir | Out-Null
        }
        $errLog = [System.IO.Path]::Combine($ExtractDir, "update_error.log")
        [System.IO.File]::WriteAllText($errLog, $_.Exception.ToString())
    }
    catch {}
    
    if (-not [string]::IsNullOrWhiteSpace($StateFile)) {
        Update-State @{ status = 'failed'; error = $_.Exception.Message }
    }
    exit 1
}
