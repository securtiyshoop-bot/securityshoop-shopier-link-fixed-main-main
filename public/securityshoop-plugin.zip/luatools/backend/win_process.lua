local fs = require("fs")
local m_utils = require("utils")
local paths = require("paths")

local win_process = {}

local NATIVE_DIR = paths.backend_path("native")
local RUNNER_DLL = fs.join(NATIVE_DIR, "securityshoop_runner.dll")
local REQUEST_FILE = fs.join(NATIVE_DIR, "securityshoop_runner.request")
local RESULT_FILE = fs.join(NATIVE_DIR, "securityshoop_runner.result")

local function quote(value)
    return '"' .. tostring(value or ""):gsub('"', '\\"') .. '"'
end

local function read_result()
    local text = tostring(m_utils.read_file(RESULT_FILE) or "")
    local status, value = text:match("^([^\r\n]+)[\r\n]+([^\r\n]+)")
    return status == "ok", tonumber(value or 0) or 0
end

function win_process.available()
    return fs.exists(RUNNER_DLL) and type(package.loadlib) == "function"
end

function win_process.run(file_path, args, wait)
    if not win_process.available() then
        return false, "Konsolsuz Windows calistiricisi bulunamadi."
    end
    pcall(fs.remove, REQUEST_FILE)
    pcall(fs.remove, RESULT_FILE)
    m_utils.write_file(REQUEST_FILE, table.concat({
        tostring(file_path or ""),
        tostring(args or ""):gsub("[\r\n]", " "),
        wait == true and "1" or "0",
        ""
    }, "\n"))
    local loader, load_error = package.loadlib(RUNNER_DLL, "luaopen_securityshoop_runner")
    if type(loader) ~= "function" then
        pcall(fs.remove, REQUEST_FILE)
        return false, "Konsolsuz calistirici yuklenemedi: " .. tostring(load_error or "")
    end
    local loaded, run_error = pcall(loader)
    if not loaded then
        pcall(fs.remove, REQUEST_FILE)
        return false, "Konsolsuz calistirici baslatilamadi: " .. tostring(run_error or "")
    end
    local ok, result = read_result()
    pcall(fs.remove, RESULT_FILE)
    if not ok then return false, "Windows islem hatasi: " .. tostring(result) end
    return true, result
end

function win_process.powershell_file(script_path, args, wait)
    local system_root = os.getenv("SystemRoot") or "C:\\Windows"
    local powershell = system_root .. "\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"
    local arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " .. quote(script_path)
    if tostring(args or "") ~= "" then arguments = arguments .. " " .. tostring(args) end
    return win_process.run(powershell, arguments, wait)
end

function win_process.open_with_explorer(target)
    local system_root = os.getenv("SystemRoot") or "C:\\Windows"
    return win_process.run(system_root .. "\\explorer.exe", quote(target), false)
end

function win_process.open_url(url)
    return win_process.open_with_explorer(tostring(url or ""))
end

return win_process
