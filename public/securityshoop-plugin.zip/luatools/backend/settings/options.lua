local options = {}

options.SETTINGS_GROUPS = {
    {
        key = "general",
        label = "General",
        description = "Global SecurityShoop preferences.",
        options = {
            {
                key = "useSteamLanguage",
                label = "Use Steam Language",
                option_type = "toggle",
                description = "Use the Steam client's language for SecurityShoop.",
                default = true,
                metadata = {yesLabel = "Yes", noLabel = "No"}
            },
            {
                key = "language",
                label = "Language",
                option_type = "select",
                description = "Choose the language used by SecurityShoop.",
                default = "tr",
                metadata = {dynamicChoices = "locales"}
            },
            {
                key = "theme",
                label = "Theme",
                option_type = "select",
                description = "Choose the color theme for SecurityShoop interface.",
                default = "securityshoop",
                metadata = {dynamicChoices = "themes"}
            },
            {
                key = "fastDownload",
                label = "Fast Download",
                option_type = "toggle",
                description = "Automatically choose the first available source when adding a game.",
                default = true,
                metadata = {yesLabel = "Yes", noLabel = "No"}
            },
            {
                key = "cleanupWatchdog",
                label = "Safe Cleanup Watchdog",
                option_type = "toggle",
                description = "Keep a quiet cleanup guard for SecurityShoop-managed games if the plugin is removed or disabled.",
                default = true,
                metadata = {yesLabel = "Yes", noLabel = "No"}
            },
            {
                key = "autoCleanupEnabled",
                label = "Automatic Old File Cleanup",
                option_type = "toggle",
                description = "Remove only expired SecurityShoop temporary download files.",
                default = true,
                metadata = {yesLabel = "Yes", noLabel = "No"}
            },
            {
                key = "autoCleanupDays",
                label = "Temporary File Retention",
                option_type = "select",
                description = "Keep temporary download files for this many days.",
                default = "7",
                choices = {
                    {value = "1", label = "1 day"},
                    {value = "3", label = "3 days"},
                    {value = "7", label = "7 days"},
                    {value = "14", label = "14 days"},
                    {value = "30", label = "30 days"}
                }
            },
            {
                key = "morrenusApiKey",
                label = "Morrenus API Key",
                option_type = "text",
                description = "Optional key for Morrenus manifest source.",
                default = "",
                metadata = {placeholder = "API key"}
            }
        }
    }
}

function options.get_settings_schema()
    local schema = {}
    for _, group in ipairs(options.SETTINGS_GROUPS) do
        local group_options = {}
        for _, opt in ipairs(group.options) do
            table.insert(group_options, {
                key = opt.key,
                label = opt.label,
                type = opt.option_type,
                description = opt.description,
                default = opt.default,
                choices = opt.choices or {},
                requiresRestart = opt.requires_restart or false,
                metadata = opt.metadata or {}
            })
        end
        table.insert(schema, {
            key = group.key,
            label = group.label,
            description = group.description,
            options = group_options
        })
    end
    return schema
end

function options.get_default_settings_values()
    local defaults = {}
    for _, group in ipairs(options.SETTINGS_GROUPS) do
        local group_defaults = {}
        for _, opt in ipairs(group.options) do
            group_defaults[opt.key] = opt.default
        end
        defaults[group.key] = group_defaults
    end
    return defaults
end

function options.merge_defaults_with_values(values)
    local merged = type(values) == "table" and values or {}
    local defaults = options.get_default_settings_values()

    for group_key, group_defaults in pairs(defaults) do
        local existing_group = merged[group_key]
        if type(existing_group) ~= "table" then
            existing_group = {}
        end
        local merged_group = {}
        for k, v in pairs(group_defaults) do merged_group[k] = v end
        for k, v in pairs(existing_group) do merged_group[k] = v end
        merged[group_key] = merged_group
    end
    return merged
end

return options
