$ErrorActionPreference='SilentlyContinue'
$p=$null
try{$p=(Get-ItemProperty 'HKCU:\Software\Valve\Steam' -Name SteamPath).SteamPath}catch{}
if(!$p){$p=(Get-ItemProperty 'HKLM:\Software\Valve\Steam' -Name InstallPath).InstallPath}
$e=if($p){Join-Path $p 'steam.exe'}else{$null}
Stop-Process -Name steam -Force
Start-Sleep 4
if($e -and (Test-Path $e)){Start-Process $e}else{Start-Process 'steam://open/main'}
