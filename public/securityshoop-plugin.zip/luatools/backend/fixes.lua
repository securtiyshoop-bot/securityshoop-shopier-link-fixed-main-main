local m_utils = require("utils")
local fs = require("fs")
local http_client = require("http_client")
local logger = require("plugin_logger")
local utils = require("plugin_utils")
local paths = require("paths")
local cjson = require("json")
local config = require("config")
local win_process = require("win_process")

local fixes = {}

function fixes.check_for_fixes(appid)
    if type(appid) == "string" then appid = tonumber(appid) end
    local result = {
        success = true,
        appid = appid,
        gameName = "Unknown Game (" .. tostring(appid) .. ")",
        genericFix = { status = 0, available = false },
        onlineFix = { status = 0, available = false }
    }
    
    local FIXES_INDEX_URL = "https://index.luatools.work/fixes-index.json"
    local resp = http_client.get(FIXES_INDEX_URL, { timeout = 10 })
    if resp and resp.status == 200 and resp.body then
        local data = utils.decode_json(resp.body)
        if type(data) == "table" then
            local generic_url = "https://files.luatools.work/GameBypasses/" .. tostring(appid) .. ".zip"
            local online_url = "https://files.luatools.work/OnlineFix1/" .. tostring(appid) .. ".zip"
            
            local has_generic = false
            for _, v in ipairs(data.genericFixes or {}) do if tonumber(v) == appid then has_generic = true break end end
            if has_generic then
                result.genericFix.status = 200
                result.genericFix.available = true
                result.genericFix.url = generic_url
            else
                result.genericFix.status = 404
            end
            
            local has_online = false
            for _, v in ipairs(data.onlineFixes or {}) do if tonumber(v) == appid then has_online = true break end end
            if has_online then
                result.onlineFix.status = 200
                result.onlineFix.available = true
                result.onlineFix.url = online_url
            else
                result.onlineFix.status = 404
            end
        end
    end
    
    return result
end

local function fix_paths(appid)
    local root = utils.ensure_temp_download_dir()
    local prefix = "fix_" .. tostring(appid)
    return {
        root = root,
        zip = fs.join(root, prefix .. ".zip"),
        state = fs.join(root, prefix .. "_state.json"),
        request = fs.join(root, prefix .. "_request.json"),
        launcher = fs.join(root, prefix .. "_hidden.vbs"),
        cancel = fs.join(root, prefix .. "_cancel")
    }
end

local function quote(value)
    return '"' .. tostring(value or ""):gsub('"', '\\"') .. '"'
end

local function cleanup_runtime_files(files, include_state)
    pcall(fs.remove, files.zip)
    pcall(fs.remove, files.request)
    pcall(fs.remove, files.launcher)
    pcall(fs.remove, files.cancel)
    if include_state then pcall(fs.remove, files.state) end
end

function fixes.apply_game_fix(appid, download_url, install_path, fix_type, game_name)
    appid = tonumber(appid)
    if not appid or appid <= 0 or appid ~= math.floor(appid) then
        return { success = false, error = "Gecersiz AppID." }
    end

    download_url = tostring(download_url or "")
    install_path = tostring(install_path or "")
    if not download_url:match("^https://") then
        return { success = false, error = "Fix indirme adresi guvenli degil." }
    end
    if install_path == "" or not fs.exists(install_path) then
        return { success = false, error = "Oyun kurulum klasoru bulunamadi." }
    end

    local files = fix_paths(appid)
    cleanup_runtime_files(files, true)
    local script_path = paths.backend_path("scripts/fix_downloader.ps1")
    if not fs.exists(script_path) then
        return { success = false, error = "Gizli fix indirici bulunamadi." }
    end

    local request = {
        appid = appid,
        url = download_url,
        installPath = install_path,
        zipPath = files.zip,
        stateFile = files.state,
        cancelFile = files.cancel,
        launcherFile = files.launcher,
        requestFile = files.request,
        userAgent = config.USER_AGENT,
        fixType = tostring(fix_type or ""),
        gameName = tostring(game_name or "")
    }
    m_utils.write_file(files.request, cjson.encode(request))
    m_utils.write_file(files.state, cjson.encode({
        status = "downloading",
        bytesRead = 0,
        totalBytes = 0,
        fixType = request.fixType
    }))

    logger.log("SecurityShoop: Starting no-window fix download appid=" .. tostring(appid))
    local launched, launch_result = win_process.powershell_file(script_path, "-RequestFile " .. quote(files.request), false)
    if not launched then
        local message = "Konsolsuz fix indirici baslatilamadi: " .. tostring(launch_result or "")
        m_utils.write_file(files.state, cjson.encode({ status = "failed", error = message }))
        return { success = false, error = message }
    end

    return { success = true, status = "downloading", appid = appid }
end

function fixes.get_apply_status(appid)
    local files = fix_paths(appid)
    
    if not fs.exists(files.state) then
        return { success = true, state = { status = "done" } }
    end
    
    local content = m_utils.read_file(files.state)
    if content and content ~= "" then
        local success, data = pcall(cjson.decode, content)
        if success and type(data) == "table" and data.status then
            if data.status == "done" or data.status == "failed" or data.status == "cancelled" then
                cleanup_runtime_files(files, true)
            end
            return { success = true, state = data }
        end
    end
    
    return { success = true, state = { status = "downloading" } }
end

function fixes.cancel_apply(appid)
    appid = tonumber(appid)
    if not appid or appid <= 0 then return { success = false, error = "Gecersiz AppID." } end
    local files = fix_paths(appid)
    if not fs.exists(files.state) then return { success = true, status = "done" } end
    m_utils.write_file(files.cancel, "cancel")
    return { success = true, status = "cancelling" }
end

return fixes
