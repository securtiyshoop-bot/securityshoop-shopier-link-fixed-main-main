local paths = require("paths")
local utils = require("plugin_utils")

local activity = {}
local HISTORY_FILE = paths.backend_path("data/activity-history.json")
local MAX_EVENTS = 200

local function read_history()
    local data = utils.read_json(HISTORY_FILE)
    if type(data) ~= "table" then data = {} end
    if type(data.events) ~= "table" then data.events = {} end
    return data
end

function activity.add(event_type, details)
    local data = read_history()
    local item = type(details) == "table" and details or { message = tostring(details or "") }
    item.type = tostring(event_type or "event")
    item.at = os.date("!%Y-%m-%dT%H:%M:%SZ")
    table.insert(data.events, 1, item)
    while #data.events > MAX_EVENTS do table.remove(data.events) end
    data.updated_at = item.at
    return utils.write_json(HISTORY_FILE, data)
end

function activity.list(limit)
    local events = read_history().events
    local result = {}
    local max = math.max(1, math.min(tonumber(limit or 50) or 50, MAX_EVENTS))
    for index = 1, math.min(#events, max) do result[index] = events[index] end
    return result
end

function activity.seed_games(games)
    local data = read_history()
    if #data.events > 0 or type(games) ~= "table" then return false end
    for _, game in ipairs(games) do
        table.insert(data.events, {
            type = "game_added",
            appid = tostring(game.appid or ""),
            name = tostring(game.name or ""),
            api = tostring(game.api or ""),
            at = tostring(game.installed_at or os.date("!%Y-%m-%dT%H:%M:%SZ")),
            imported = true
        })
    end
    data.updated_at = os.date("!%Y-%m-%dT%H:%M:%SZ")
    return utils.write_json(HISTORY_FILE, data)
end

return activity
