local paths = require("paths")
local utils = require("plugin_utils")

local guard = {}
local FILE = paths.backend_path("data/package-quarantine.json")
local DEFAULT_SECONDS = 6 * 60 * 60

local function key(appid, source)
    return tostring(appid or "") .. "|" .. tostring(source or "unknown"):lower()
end

local function read_data()
    local data = utils.read_json(FILE)
    if type(data) ~= "table" then data = {} end
    if type(data.items) ~= "table" then data.items = {} end
    return data
end

local function write_data(data)
    data.updated_at = os.date("!%Y-%m-%dT%H:%M:%SZ")
    return utils.write_json(FILE, data)
end

function guard.is_quarantined(appid, source)
    local data = read_data()
    local item = data.items[key(appid, source)]
    if type(item) ~= "table" then return false, nil end
    if tonumber(item.until_epoch or 0) <= os.time() then
        data.items[key(appid, source)] = nil
        write_data(data)
        return false, nil
    end
    return true, item
end

function guard.quarantine(appid, source, reason, package_info)
    local data = read_data()
    local item_key = key(appid, source)
    local old = type(data.items[item_key]) == "table" and data.items[item_key] or {}
    package_info = type(package_info) == "table" and package_info or {}
    data.items[item_key] = {
        appid = tostring(appid or ""),
        source = tostring(source or "unknown"),
        reason = tostring(reason or "Paket dogrulanamadi."),
        failures = (tonumber(old.failures or 0) or 0) + 1,
        sha256 = tostring(package_info.sha256 or ""),
        bytes = tonumber(package_info.bytes or 0) or 0,
        quarantined_at = os.date("!%Y-%m-%dT%H:%M:%SZ"),
        until_epoch = os.time() + DEFAULT_SECONDS
    }
    write_data(data)
    return data.items[item_key]
end

function guard.clear(appid, source)
    local data = read_data()
    data.items[key(appid, source)] = nil
    return write_data(data)
end

function guard.list()
    local data = read_data()
    local items = {}
    for _, item in pairs(data.items) do
        if type(item) == "table" and tonumber(item.until_epoch or 0) > os.time() then table.insert(items, item) end
    end
    return items
end

return guard
