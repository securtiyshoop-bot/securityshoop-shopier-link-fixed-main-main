local cjson = require("json")
local fs = require("fs")
local m_utils = require("utils")
local paths = require("paths")
local activity = require("activity_log")
local steam_utils = require("steam_utils")
local utils = require("plugin_utils")

local registry = {}

local REGISTRY_FILE = paths.backend_path("data/installed-games.json")
local MANAGED_MARKER = "securityshoop-managed"
local EXTERNAL_REGISTRY_NAME = "securityshoop-managed-games.json"
local ACTIVE_MARKER_NAME = "securityshoop-active.json"
local CLEANUP_SCRIPT_NAME = "SecurityShoopCleanup.ps1"
local WATCHDOG_SCRIPT_NAME = "SecurityShoopCleanupWatchdog.js"
local LEGACY_WATCHDOG_SCRIPT_NAME = "SecurityShoopCleanupWatchdog.ps1"
local WATCHDOG_TASK_NAME = "SecurityShoopCleanupWatchdog"
local WATCHDOG_STATE_VERSION = "8.5.2-cleanup-task"
local WATCHDOG_STATE_FILE = paths.backend_path("data/watchdog-installed.json")

local function ensure_parent_dir(path)
    local dir = fs.parent_path(path)
    if dir and dir ~= "" and not fs.exists(dir) then fs.create_directories(dir) end
end

local function normalize_appid(value)
    local text = tostring(value or ""):match("(%d+)")
    return text or ""
end

local function read_registry()
    local data = utils.read_json(REGISTRY_FILE)
    if type(data) ~= "table" then data = {} end
    if type(data.games) ~= "table" then data.games = {} end
    return data
end

local function write_registry(data)
    ensure_parent_dir(REGISTRY_FILE)
    return utils.write_json(REGISTRY_FILE, data or { games = {} })
end

local function steam_paths()
    local base = steam_utils.detect_steam_install_path()
    if not base or base == "" then return nil end
    return {
        base = base,
        lua_dir = fs.join(base, "config", "stplug-in"),
        depotcache = fs.join(base, "depotcache")
    }
end

local function safe_manifest_name(name)
    local clean = tostring(name or "")
    if clean:match("^[%w%._%-]+%.manifest$") then return clean end
    return ""
end

local add_unique

local function external_registry_path(paths_info)
    if not paths_info then return "" end
    return fs.join(paths_info.base, "config", EXTERNAL_REGISTRY_NAME)
end

local function active_marker_path(paths_info)
    if not paths_info then return "" end
    return fs.join(paths_info.base, "config", ACTIVE_MARKER_NAME)
end

local function cleanup_script_path(paths_info)
    if not paths_info then return "" end
    return fs.join(paths_info.base, "config", CLEANUP_SCRIPT_NAME)
end

local function watchdog_script_path(paths_info)
    if not paths_info then return "" end
    return fs.join(paths_info.base, "config", WATCHDOG_SCRIPT_NAME)
end

local function legacy_watchdog_script_path(paths_info)
    if not paths_info then return "" end
    return fs.join(paths_info.base, "config", LEGACY_WATCHDOG_SCRIPT_NAME)
end

local function is_managed_lua(text)
    local content = tostring(text or "")
    return content:find(MANAGED_MARKER, 1, true) ~= nil or
        content:find("SecurityShoop managed", 1, true) ~= nil
end

local function read_external_registry(paths_info)
    local path = external_registry_path(paths_info)
    if path == "" or not fs.exists(path) then return { games = {} } end
    local data = utils.read_json(path)
    if type(data) ~= "table" then data = {} end
    if type(data.games) ~= "table" then data.games = {} end
    return data
end

local function write_external_registry(paths_info, data)
    local path = external_registry_path(paths_info)
    if path == "" then return false end
    ensure_parent_dir(path)
    data = type(data) == "table" and data or {}
    data.name = "SecurityShoop managed games"
    data.trust_registry = true
    data.plugin_dir = paths.get_plugin_dir()
    data.updated_at = os.date("!%Y-%m-%dT%H:%M:%SZ")
    if type(data.games) ~= "table" then data.games = {} end
    return utils.write_json(path, data)
end

local function normalize_entry(game)
    local appid = normalize_appid(game and game.appid)
    if appid == "" then return nil end
    local manifests = {}
    if type(game.manifest_files) == "table" then
        for _, item in ipairs(game.manifest_files) do
            local clean = safe_manifest_name(item)
            if clean ~= "" then add_unique(manifests, clean) end
        end
    end
    return {
        appid = appid,
        name = tostring((game and (game.name or game.title)) or ("AppID " .. appid)),
        api = tostring((game and game.api) or ""),
        lua_path = tostring((game and game.lua_path) or ""),
        manifest_files = manifests,
        installed_at = tostring((game and game.installed_at) or os.date("!%Y-%m-%dT%H:%M:%SZ")),
        package_sha256 = tostring((game and game.package_sha256) or ""),
        package_bytes = tonumber((game and game.package_bytes) or 0) or 0,
        verified_at = tostring((game and game.verified_at) or "")
    }
end

local function merge_game(list, entry)
    entry = normalize_entry(entry)
    if not entry then return end
    for index, game in ipairs(list) do
        if normalize_appid(game.appid) == entry.appid then
            list[index] = entry
            return
        end
    end
    table.insert(list, 1, entry)
end

local function write_cleanup_scripts(paths_info)
    if not paths_info then return false end
    local config_dir = fs.join(paths_info.base, "config")
    if not fs.exists(config_dir) then fs.create_directories(config_dir) end

    local cleanup_script = [[$ErrorActionPreference = "SilentlyContinue"
$configDir = $PSScriptRoot
$steamDir = Split-Path -Parent $configDir
$registryPath = Join-Path $configDir "securityshoop-managed-games.json"
$luaDir = Join-Path $steamDir "config\stplug-in"
$depotDir = Join-Path $steamDir "depotcache"

if (-not (Test-Path -LiteralPath $registryPath)) { exit 0 }

try {
    $data = Get-Content -LiteralPath $registryPath -Raw | ConvertFrom-Json
} catch {
    exit 0
}

$games = @($data.games)
foreach ($game in $games) {
    $appid = [string]$game.appid -replace '[^\d]', ''
    if ([string]::IsNullOrWhiteSpace($appid)) { continue }

    foreach ($name in @("$appid.lua", "$appid.lua.disabled")) {
        $path = Join-Path $luaDir $name
        if (Test-Path -LiteralPath $path) {
            $text = ""
            try { $text = Get-Content -LiteralPath $path -Raw } catch {}
            if ($text -match "securityshoop-managed" -or $text -match "SecurityShoop managed" -or $data.trust_registry -eq $true) {
                try { Remove-Item -LiteralPath $path -Force } catch {}
            }
        }
    }

    foreach ($manifest in @($game.manifest_files)) {
        $clean = [string]$manifest
        if ($clean -notmatch '^[\w\.\-]+\.manifest$') { continue }
        $manifestPath = Join-Path $depotDir $clean
        if (Test-Path -LiteralPath $manifestPath) {
            try { Remove-Item -LiteralPath $manifestPath -Force } catch {}
        }
    }
}

try {
    $cleaned = [ordered]@{
        name = "SecurityShoop managed games"
        trust_registry = $true
        plugin_dir = $data.plugin_dir
        games = @()
        cleaned_at = (Get-Date).ToUniversalTime().ToString("o")
    }
    $cleaned | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $registryPath -Encoding UTF8 -Force
} catch {}
]]

    local watchdog_script = [=[var fso = new ActiveXObject("Scripting.FileSystemObject");

function readText(path) {
    try {
        if (!fso.FileExists(path)) return "";
        var file = fso.OpenTextFile(path, 1, false);
        var text = file.ReadAll();
        file.Close();
        if (text.length && text.charCodeAt(0) === 0xFEFF) text = text.substring(1);
        if (text.length >= 3 && text.charCodeAt(0) === 0xEF && text.charCodeAt(1) === 0xBB && text.charCodeAt(2) === 0xBF) text = text.substring(3);
        return text;
    } catch (e) {
        return "";
    }
}

function writeText(path, text) {
    try {
        var file = fso.OpenTextFile(path, 2, true);
        file.Write(text);
        file.Close();
        return true;
    } catch (e) {}
    return false;
}

function parseJson(text) {
    try { return eval("(" + text + ")"); } catch (e) { return null; }
}

function asArray(value) {
    if (value === null || typeof value === "undefined") return [];
    if (typeof value !== "string" && typeof value.length === "number") {
        var out = [];
        for (var i = 0; i < value.length; i++) out.push(value[i]);
        return out;
    }
    if (typeof value === "string") return [value];
    return [];
}

function jsonEscape(value) {
    return String(value || "").replace(/\\/g, "\\\\").replace(/"/g, "\\\"").replace(/\r/g, "\\r").replace(/\n/g, "\\n");
}

function cleanAppid(value) {
    var match = String(value || "").match(/\d+/);
    return match ? match[0] : "";
}

function safeManifest(value) {
    var text = String(value || "");
    return /^[A-Za-z0-9_.-]+\.manifest$/.test(text) ? text : "";
}

function pad2(value) {
    value = Number(value || 0);
    return value < 10 ? "0" + String(value) : String(value);
}

function isoNow() {
    var date = new Date();
    return String(date.getUTCFullYear()) + "-" +
        pad2(date.getUTCMonth() + 1) + "-" +
        pad2(date.getUTCDate()) + "T" +
        pad2(date.getUTCHours()) + ":" +
        pad2(date.getUTCMinutes()) + ":" +
        pad2(date.getUTCSeconds()) + "Z";
}

function deleteFile(path) {
    try {
        if (fso.FileExists(path)) {
            fso.DeleteFile(path, true);
            return !fso.FileExists(path);
        }
    } catch (e) {}
    return false;
}

function fileContainsManagedMarker(path, trustRegistry) {
    if (trustRegistry) return true;
    var text = readText(path);
    return text.indexOf("securityshoop-managed") >= 0 || text.indexOf("SecurityShoop managed") >= 0;
}

function listHasSecurityShoop(value) {
    var list = asArray(value);
    for (var i = 0; i < list.length; i++) {
        var name = String(list[i] || "").toLowerCase();
        if (name === "luatools" || name === "securityshoop") return true;
    }
    return false;
}

var configDir = fso.GetParentFolderName(WScript.ScriptFullName);
var steamDir = fso.GetParentFolderName(configDir);
var registryPath = fso.BuildPath(configDir, "securityshoop-managed-games.json");
if (!fso.FileExists(registryPath)) WScript.Quit(0);

var data = parseJson(readText(registryPath));
if (!data) WScript.Quit(0);
var games = asArray(data.games);
if (!games.length) WScript.Quit(0);

var pluginDir = String(data.plugin_dir || "");
var pluginMissing = pluginDir !== "" && !fso.FolderExists(pluginDir);
var pluginBroken = false;
if (pluginDir !== "" && fso.FolderExists(pluginDir)) {
    var backendDir = fso.BuildPath(pluginDir, "backend");
    var publicDir = fso.BuildPath(pluginDir, "public");
    pluginBroken =
        !fso.FileExists(fso.BuildPath(pluginDir, "plugin.json")) ||
        !fso.FileExists(fso.BuildPath(backendDir, "main.lua")) ||
        !fso.FileExists(fso.BuildPath(publicDir, "luatools.js"));
}

var pluginDisabled = false;
var cfgPath = fso.BuildPath(steamDir, "millennium\\config\\config.json");
if (fso.FileExists(cfgPath)) {
    var cfg = parseJson(readText(cfgPath));
    if (cfg) {
        if (typeof cfg["plugins.enabledPlugins"] !== "undefined") {
            pluginDisabled = !listHasSecurityShoop(cfg["plugins.enabledPlugins"]);
        } else if (cfg.plugins && typeof cfg.plugins.enabledPlugins !== "undefined") {
            pluginDisabled = !listHasSecurityShoop(cfg.plugins.enabledPlugins);
        }
    }
}

if (!pluginMissing && !pluginBroken && !pluginDisabled) WScript.Quit(0);

var luaDir = fso.BuildPath(fso.BuildPath(steamDir, "config"), "stplug-in");
var depotDir = fso.BuildPath(steamDir, "depotcache");
var trustRegistry = data.trust_registry === true;
var cleanedAny = games.length > 0;

for (var gi = 0; gi < games.length; gi++) {
    var game = games[gi] || {};
    var appid = cleanAppid(game.appid);
    if (!appid) continue;

    var luaNames = [appid + ".lua", appid + ".lua.disabled"];
    for (var l = 0; l < luaNames.length; l++) {
        var luaPath = fso.BuildPath(luaDir, luaNames[l]);
        if (fso.FileExists(luaPath) && fileContainsManagedMarker(luaPath, trustRegistry)) {
            if (deleteFile(luaPath)) cleanedAny = true;
        }
    }

    var manifests = asArray(game.manifest_files);
    for (var mi = 0; mi < manifests.length; mi++) {
        var manifest = safeManifest(manifests[mi]);
        if (manifest && deleteFile(fso.BuildPath(depotDir, manifest))) cleanedAny = true;
    }
}

var cleaned = "{\n" +
    "  \"name\": \"SecurityShoop managed games\",\n" +
    "  \"trust_registry\": true,\n" +
    "  \"plugin_dir\": \"" + jsonEscape(pluginDir) + "\",\n" +
    "  \"games\": [],\n" +
    "  \"cleaned_at\": \"" + jsonEscape(isoNow()) + "\"\n" +
    "}\n";
writeText(registryPath, cleaned);

if (pluginDir !== "" && fso.FolderExists(pluginDir)) {
    var internalRegistryPath = fso.BuildPath(fso.BuildPath(fso.BuildPath(pluginDir, "backend"), "data"), "installed-games.json");
    writeText(internalRegistryPath, cleaned);
}

// v8.5.2 no-cmd: temizleme yapilir, Steam asla izinsiz kapatilip acilmaz.
cleanedAny = cleanedAny;
]=]

    m_utils.write_file(cleanup_script_path(paths_info), cleanup_script)
    m_utils.write_file(watchdog_script_path(paths_info), watchdog_script)
    return true
end

local function sync_external_from_plugin_registry(paths_info)
    if not paths_info then return false end
    local plugin_data = read_registry()
    local external = read_external_registry(paths_info)
    external.games = type(external.games) == "table" and external.games or {}
    for _, game in ipairs(plugin_data.games or {}) do
        merge_game(external.games, game)
    end
    return write_external_registry(paths_info, external)
end

add_unique = function(list, value)
    local clean = tostring(value or "")
    if clean == "" then return end
    for _, item in ipairs(list) do
        if tostring(item) == clean then return end
    end
    table.insert(list, clean)
end

function registry.extract_manifest_files_from_lua(text)
    local files = {}
    local content = tostring(text or "")
    for depot, manifest in content:gmatch("setManifestid%s*%(%s*['\"]?(%d+)['\"]?%s*,%s*['\"]?(%d+)") do
        add_unique(files, tostring(depot) .. "_" .. tostring(manifest) .. ".manifest")
    end
    return files
end

local function scan_lua_games(existing)
    local paths_info = steam_paths()
    if not paths_info or not fs.exists(paths_info.lua_dir) then return existing end
    local ok_list, files = pcall(fs.list, paths_info.lua_dir)
    if not ok_list or type(files) ~= "table" then return existing end

    for _, entry in ipairs(files) do
        local name = tostring(entry.name or "")
        local appid = name:match("^(%d+)%.lua$") or name:match("^(%d+)%.lua%.disabled$")
        if appid and appid ~= "" then
            local path = entry.path or fs.join(paths_info.lua_dir, name)
            local manifests = {}
            local text = ""
            if fs.exists(path) then
                text = m_utils.read_file(path) or ""
                manifests = registry.extract_manifest_files_from_lua(text)
            end
            if existing[appid] or is_managed_lua(text) then
                existing[appid] = existing[appid] or {
                    appid = appid,
                    name = "AppID " .. appid,
                    lua_path = path,
                    manifest_files = {},
                    api = "",
                    installed_at = ""
                }
                existing[appid].lua_path = path
                for _, item in ipairs(manifests) do
                    add_unique(existing[appid].manifest_files, item)
                end
            end
        end
    end
    return existing
end

local function registered_games_map()
    local data = read_registry()
    local by_appid = {}
    local sources = { data.games or {} }
    local paths_info = steam_paths()
    if paths_info then
        table.insert(sources, read_external_registry(paths_info).games or {})
    end

    for _, source_games in ipairs(sources) do
        for _, game in ipairs(source_games or {}) do
            local appid = normalize_appid(game.appid)
            if appid ~= "" then
                local manifests = {}
                if type(game.manifest_files) == "table" then
                    for _, item in ipairs(game.manifest_files) do
                        local clean = safe_manifest_name(item)
                        if clean ~= "" then add_unique(manifests, clean) end
                    end
                end
                by_appid[appid] = {
                    appid = appid,
                    name = tostring(game.name or game.title or ("AppID " .. appid)),
                    lua_path = tostring(game.lua_path or ""),
                    manifest_files = manifests,
                    api = tostring(game.api or ""),
                    installed_at = tostring(game.installed_at or "")
                }
            end
        end
    end
    return by_appid
end

local function sorted_games_from_map(by_appid)
    local games = {}
    for _, game in pairs(by_appid) do table.insert(games, game) end
    table.sort(games, function(a, b)
        return tostring(a.name or a.appid):lower() < tostring(b.name or b.appid):lower()
    end)
    return games
end

function registry.list_registered_games()
    return sorted_games_from_map(registered_games_map())
end

function registry.list_games()
    local by_appid = registered_games_map()
    scan_lua_games(by_appid)
    return sorted_games_from_map(by_appid)
end

function registry.is_registered(appid)
    local clean_appid = normalize_appid(appid)
    if clean_appid == "" then return false, nil end
    for _, game in ipairs(registry.list_registered_games()) do
        if normalize_appid(game.appid) == clean_appid then return true, game end
    end
    return false, nil
end

function registry.record_game(appid, name, api_name, lua_path, manifest_files, package_info)
    local clean_appid = normalize_appid(appid)
    if clean_appid == "" then return false end

    local data = read_registry()
    local manifests = {}
    if type(manifest_files) == "table" then
        for _, item in ipairs(manifest_files) do
            local clean = safe_manifest_name(item)
            if clean ~= "" then add_unique(manifests, clean) end
        end
    end

    package_info = type(package_info) == "table" and package_info or {}
    local entry = {
        appid = clean_appid,
        name = tostring(name or ""):match("^%s*(.-)%s*$") or "",
        api = tostring(api_name or ""),
        lua_path = tostring(lua_path or ""),
        manifest_files = manifests,
        installed_at = os.date("!%Y-%m-%dT%H:%M:%SZ"),
        package_sha256 = tostring(package_info.sha256 or ""),
        package_bytes = tonumber(package_info.bytes or 0) or 0,
        verified_at = tostring(package_info.verified_at or os.date("!%Y-%m-%dT%H:%M:%SZ"))
    }
    if entry.name == "" then entry.name = "AppID " .. clean_appid end

    local updated = false
    for index, game in ipairs(data.games) do
        if normalize_appid(game.appid) == clean_appid then
            data.games[index] = entry
            updated = true
            break
        end
    end
    if not updated then table.insert(data.games, 1, entry) end

    local ok_write = write_registry(data)
    local paths_info = steam_paths()
    if paths_info then
        local external = read_external_registry(paths_info)
        external.games = type(external.games) == "table" and external.games or {}
        merge_game(external.games, entry)
        write_external_registry(paths_info, external)
        write_cleanup_scripts(paths_info)
    end
    pcall(activity.add, "game_added", {
        appid = clean_appid,
        name = entry.name,
        api = entry.api,
        sha256 = entry.package_sha256,
        bytes = entry.package_bytes
    })
    return ok_write
end

local function build_selected_set(appids)
    if appids == nil then return nil, false end
    if type(appids) == "string" then
        local ok, decoded = pcall(cjson.decode, appids)
        if ok and type(decoded) == "table" then appids = decoded end
    end
    if type(appids) ~= "table" then return {}, true end
    local set = {}
    local count = 0
    for _, value in ipairs(appids) do
        local appid = normalize_appid(value)
        if appid ~= "" then
            set[appid] = true
            count = count + 1
        end
    end
    return set, true
end

local function remove_existing_file(path)
    if not fs.exists(path) then return nil end
    local ok, result = pcall(fs.remove, path)
    if ok and result ~= false then return true end
    return false
end

function registry.cleanup_games(appids)
    local paths_info = steam_paths()
    if not paths_info then return false, "Steam klasoru bulunamadi.", {} end

    local selected, explicit_selection = build_selected_set(appids)
    if explicit_selection and not next(selected) then
        return true, "Secili oyun bulunamadi.", {}
    end
    local all_games = registry.list_games()
    local selected_games = {}
    local known = {}

    for _, game in ipairs(all_games) do
        local appid = normalize_appid(game.appid)
        if appid ~= "" and (not selected or selected[appid]) then
            selected_games[appid] = game
            known[appid] = true
        end
    end

    if selected then
        for appid in pairs(selected) do
            if not known[appid] then
                selected_games[appid] = { appid = appid, name = "AppID " .. appid, manifest_files = {} }
            end
        end
    end

    local removed_lua = 0
    local removed_manifest = 0
    local failed = 0
    local cleaned = {}

    for appid, game in pairs(selected_games) do
        local lua_names = { appid .. ".lua", appid .. ".lua.disabled" }
        local manifest_files = {}
        if type(game.manifest_files) == "table" then
            for _, item in ipairs(game.manifest_files) do add_unique(manifest_files, safe_manifest_name(item)) end
        end

        for _, lua_name in ipairs(lua_names) do
            local lua_path = fs.join(paths_info.lua_dir, lua_name)
            if fs.exists(lua_path) then
                local text = m_utils.read_file(lua_path) or ""
                for _, item in ipairs(registry.extract_manifest_files_from_lua(text)) do add_unique(manifest_files, item) end
                if remove_existing_file(lua_path) then removed_lua = removed_lua + 1 else failed = failed + 1 end
            end
        end

        for _, manifest_name in ipairs(manifest_files) do
            local clean = safe_manifest_name(manifest_name)
            if clean ~= "" then
                local manifest_path = fs.join(paths_info.depotcache, clean)
                if fs.exists(manifest_path) then
                    if remove_existing_file(manifest_path) then removed_manifest = removed_manifest + 1 else failed = failed + 1 end
                end
            end
        end

        table.insert(cleaned, {
            appid = appid,
            name = tostring(game.name or ("AppID " .. appid)),
            manifest_count = #manifest_files
        })
    end

    local data = read_registry()
    local kept = {}
    for _, game in ipairs(data.games or {}) do
        local appid = normalize_appid(game.appid)
        if appid ~= "" and not selected_games[appid] then table.insert(kept, game) end
    end
    data.games = kept
    write_registry(data)

    local external = read_external_registry(paths_info)
    local external_kept = {}
    for _, game in ipairs(external.games or {}) do
        local appid = normalize_appid(game.appid)
        if appid ~= "" and not selected_games[appid] then table.insert(external_kept, game) end
    end
    external.games = external_kept
    write_external_registry(paths_info, external)
    write_cleanup_scripts(paths_info)

    for _, game in ipairs(cleaned) do
        pcall(activity.add, "game_removed", {
            appid = game.appid,
            name = game.name,
            manifest_count = game.manifest_count
        })
    end

    local message = tostring(removed_lua) .. " oyun scripti ve " .. tostring(removed_manifest) .. " manifest silindi."
    if failed > 0 then
        return false, message .. " " .. tostring(failed) .. " dosya silinemedi.", cleaned
    end
    return true, message, cleaned
end

function registry.ensure_cleanup_assets()
    local paths_info = steam_paths()
    if not paths_info then return false end
    sync_external_from_plugin_registry(paths_info)
    write_cleanup_scripts(paths_info)
    local legacy = legacy_watchdog_script_path(paths_info)
    if legacy ~= "" and fs.exists(legacy) then pcall(fs.remove, legacy) end
    return true
end

function registry.touch_active_marker()
    local paths_info = steam_paths()
    if not paths_info then return false end
    local path = active_marker_path(paths_info)
    ensure_parent_dir(path)
    return utils.write_json(path, {
        name = "SecurityShoop active marker",
        plugin_dir = paths.get_plugin_dir(),
        state = "active",
        updated_at = os.date("!%Y-%m-%dT%H:%M:%SZ")
    })
end

function registry.install_cleanup_watchdog()
    local paths_info = steam_paths()
    if not paths_info then return false, "Steam klasoru bulunamadi." end
    registry.ensure_cleanup_assets()
    registry.touch_active_marker()
    utils.write_json(WATCHDOG_STATE_FILE, {
        installed = true,
        version = WATCHDOG_STATE_VERSION,
        scheduled_task = true,
        task_name = WATCHDOG_TASK_NAME,
        no_cmd_window = true,
        watchdog_path = watchdog_script_path(paths_info),
        installed_at = os.date("!%Y-%m-%dT%H:%M:%SZ")
    })
    return true, "Watchdog dosyalari hazir; sessiz Windows gorevi disaridan etkin."
end

function registry.ensure_cleanup_watchdog_installed()
    local state = utils.read_json(WATCHDOG_STATE_FILE)
    if type(state) == "table" and state.installed == true and tostring(state.version or "") == WATCHDOG_STATE_VERSION then
        return true, "Watchdog zaten hazir."
    end
    return registry.install_cleanup_watchdog()
end

function registry.remove_cleanup_watchdog()
    if fs.exists(WATCHDOG_STATE_FILE) then pcall(fs.remove, WATCHDOG_STATE_FILE) end
    return true, "Watchdog marker kaldirildi."
end

return registry
