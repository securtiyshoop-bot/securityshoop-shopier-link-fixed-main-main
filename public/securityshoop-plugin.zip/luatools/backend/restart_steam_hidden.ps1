$wmi=[wmiclass]'Win32_Process'
$ps="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$f='c:\program files (x86)\steam\millennium\plugins\luatools\backend\restart_steam_inner.ps1'
$null=$wmi.Create("$ps -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$f`"")
