-- SecurityShoop backend main.lua
-- All exported functions return JSON-encoded strings, mirroring the Python backend's json.dumps() returns.
-- This is required because Millennium's Lua bridge does not deep-serialize nested Lua tables.

local cjson            = require("json")
local m_utils          = require("utils")
local logger           = require("plugin_logger")
local millennium       = require("millennium")
local fs               = require("fs")
local http_client      = require("http_client")
local paths            = require("paths")
local steam_utils      = require("steam_utils")
local utils            = require("plugin_utils")
local locales_mod      = require("locales.manager")

local api_manifest     = require("api_manifest")
local downloads        = require("downloads")
local fixes            = require("fixes")
local settings_manager = require("settings.manager")
local auto_update      = require("auto_update")
local auth             = require("auth")
local game_registry    = require("game_registry")
local activity_log     = require("activity_log")
local package_guard    = require("package_guard")
local temp_cleanup     = require("temp_cleanup")

local copy_webkit_files

-- ── Helpers ──────────────────────────────────────────────────────────────────

--- Safely encode a Lua table to a JSON string (same as Python json.dumps).
local function json_ok(data)
    local ok, s = pcall(cjson.encode, data)
    if ok then return s end
    logger.warn("json_ok encode failed: " .. tostring(s))
    return '{"success":false,"error":"serialization error"}'
end

local function json_err(msg)
    return json_ok({ success = false, error = tostring(msg) })
end

local function decode_payload_arg(value)
    if type(value) == "table" then
        if type(value.accountPayload) == "string" then
            local nested = decode_payload_arg(value.accountPayload)
            if type(nested) == "table" then
                for k, v in pairs(value) do
                    if nested[k] == nil then nested[k] = v end
                end
                return nested
            end
        end
        return value
    end
    if type(value) ~= "string" then return nil end
    local text = value:match("^%s*(.-)%s*$") or ""
    if text:sub(1, 1) ~= "{" then return nil end
    local ok, parsed = pcall(cjson.decode, text)
    if ok and type(parsed) == "table" then return parsed end
    return nil
end

local function looks_like_email(value)
    return type(value) == "string" and value:find("@", 1, true) ~= nil
end

local function value_or_empty(value)
    return tostring(value or "")
end

local function username_from_email(email)
    local name = tostring(email or ""):match("^([^@]+)@")
    if name and name ~= "" then return name end
    return ""
end

local function compact_auth_result(res)
    res = res or {}
    local user = res.user or {}
    return {
        success = res.success == true,
        authenticated = res.success == true and tostring(user.token or "") ~= "",
        status = tonumber(res.status or 0) or 0,
        message = tostring(res.message or ""),
        error = tostring(res.error or ""),
        pending_approval = res.pending_approval == true,
        hwid = tostring(res.hwid or ""),
        user = {
            id = user.id,
            username = tostring(user.username or ""),
            email = tostring(user.email or ""),
            role = tostring(user.role or "user"),
            token = tostring(user.token or ""),
            license_until = tostring(user.license_until or ""),
            daily_limit = tonumber(user.daily_limit or 0) or 0,
            allowed_appids = user.allowed_appids or {},
            approval_status = tostring(user.approval_status or "approved")
        }
    }
end

local function cleanup_installed_lua_scripts(appids)
    local ok, success, message = pcall(function()
        local ok_cleanup, cleanup_message = game_registry.cleanup_games(appids)
        return ok_cleanup, cleanup_message
    end)
    if not ok then return false, tostring(success) end
    return success == true, tostring(message or "")
end

local function count_list(value)
    if type(value) ~= "table" then return 0 end
    local count = 0
    for _, _ in pairs(value) do count = count + 1 end
    return count
end

local function read_file_text(path)
    path = tostring(path or "")
    if path == "" or not fs.exists(path) then return "" end
    local ok, content = pcall(m_utils.read_file, path)
    if ok and type(content) == "string" then return content end
    return ""
end

local function base64_decode(data)
    data = tostring(data or ""):gsub("%s", "")
    local chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    local map = {}
    for i = 1, #chars do map[chars:sub(i, i)] = i - 1 end
    local out = {}
    local buffer = 0
    local bits = 0
    for i = 1, #data do
        local ch = data:sub(i, i)
        if ch == "=" then break end
        local value = map[ch]
        if value then
            buffer = buffer * 64 + value
            bits = bits + 6
            while bits >= 8 do
                bits = bits - 8
                local byte = math.floor(buffer / (2 ^ bits)) % 256
                table.insert(out, string.char(byte))
                buffer = buffer % (2 ^ bits)
            end
        end
    end
    return table.concat(out)
end

local function base64_encode(data)
    data = tostring(data or "")
    if m_utils.base64_encode then
        local ok, encoded = pcall(m_utils.base64_encode, data)
        if ok and type(encoded) == "string" and encoded ~= "" then return encoded end
    end
    local chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    return ((data:gsub(".", function(x)
        local r = ""
        local byte = x:byte()
        for i = 8, 1, -1 do
            r = r .. (byte % 2 ^ i - byte % 2 ^ (i - 1) > 0 and "1" or "0")
        end
        return r
    end) .. "0000"):gsub("%d%d%d?%d?%d?%d?", function(x)
        if #x < 6 then return "" end
        local c = 0
        for i = 1, 6 do
            c = c + (x:sub(i, i) == "1" and 2 ^ (6 - i) or 0)
        end
        return chars:sub(c + 1, c + 1)
    end) .. ({ "", "==", "=" })[#data % 3 + 1])
end

local function safe_package_filename(name)
    local clean = tostring(name or ""):gsub("\\", "/"):match("([^/]+)$") or ""
    if clean:find("%.%.", 1, true) then return "" end
    return clean
end

local function package_body_looks_like_zip(body)
    body = tostring(body or "")
    if #body < 22 then return false end
    local b1, b2, b3, b4 = body:byte(1, 4)
    if b1 ~= 0x50 or b2 ~= 0x4b then return false end
    if not (b3 == 0x03 or b3 == 0x05 or b3 == 0x07) then return false end
    if not (b4 == 0x04 or b4 == 0x06 or b4 == 0x08) then return false end
    return true
end

local function probe_integrity_file(label, path, markers)
    path = tostring(path or "")
    local content = read_file_text(path)
    local missing = {}
    for _, marker in ipairs(markers or {}) do
        marker = tostring(marker or "")
        if marker ~= "" and content:find(marker, 1, true) == nil then
            table.insert(missing, marker)
        end
    end
    return {
        label = tostring(label or path),
        path = path,
        exists = content ~= "",
        bytes = #content,
        ok = content ~= "" and #missing == 0,
        missing = missing
    }
end

local function build_plugin_integrity_status()
    local version = tostring(utils.get_plugin_version() or "")
    local plugin_dir = paths.get_plugin_dir()
    local public_dir = fs.join(plugin_dir, "public")
    local steam_dir = steam_utils.detect_steam_install_path()
    local webkit_js = steam_dir and steam_dir ~= "" and fs.join(steam_dir, "steamui", "webkit", "luatools.js") or ""
    local files = {
        probe_integrity_file("plugin.json", fs.join(plugin_dir, "plugin.json"), {
            '"common_name": "SecurityShoop"',
            '"version": "' .. version .. '"'
        }),
        probe_integrity_file("backend/main.lua", paths.backend_path("main.lua"), {
            "GetInstalledLuaScripts",
            "bridge_safe_array",
            "GetPluginIntegrityStatus"
        }),
        probe_integrity_file("backend/auth.lua", paths.backend_path("auth.lua"), {
            'PLUGIN_VERSION = "' .. version .. '"'
        }),
        probe_integrity_file("public/luatools.js", fs.join(public_dir, "luatools.js"), {
            'window.__SecurityShoopSingleInstanceVersion = "' .. version .. '"',
            "v8.5.2 security",
            "GetPluginIntegrityStatus"
        }),
        probe_integrity_file("steamui/webkit/luatools.js", webkit_js, {
            'window.__SecurityShoopSingleInstanceVersion = "' .. version .. '"'
        })
    }

    local ok = true
    local missing_count = 0
    for _, item in ipairs(files) do
        if item.ok ~= true then
            ok = false
            missing_count = missing_count + #item.missing
            if item.exists ~= true then missing_count = missing_count + 1 end
        end
    end

    return {
        success = true,
        ok = ok,
        version = version,
        transparent_guard = true,
        files = files,
        missing_count = missing_count,
        message = ok and "Plugin dosya butunlugu tam." or "Plugin dosya butunlugu uyarisi var; onarim calistir."
    }
end

local function build_plugin_health_shield_status(repair)
    local report = {
        success = true,
        repaired = repair == true,
        shield = "ok",
        checks = {},
        messages = {}
    }

    if repair == true then
        local ok_temp, temp_err = pcall(utils.ensure_temp_download_dir)
        report.temp_ready = ok_temp == true
        if not ok_temp then
            report.success = false
            table.insert(report.messages, "Temp klasoru hazirlanamadi: " .. tostring(temp_err))
        end
    end

    local ok_assets, assets_result = pcall(game_registry.ensure_cleanup_assets)
    report.cleanup_assets = ok_assets == true and assets_result == true
    if report.cleanup_assets then
        table.insert(report.checks, "cleanup_assets")
    else
        report.success = false
        table.insert(report.messages, "Cleanup assetleri hazir degil.")
    end

    local ok_marker, marker_result = pcall(game_registry.touch_active_marker)
    report.active_marker = ok_marker == true and marker_result == true
    if report.active_marker then
        table.insert(report.checks, "active_marker")
    else
        report.success = false
        table.insert(report.messages, "Aktif marker yazilamadi.")
    end

    local ok_enabled, enabled = pcall(settings_manager.get_cleanup_watchdog_enabled)
    report.watchdog_enabled = ok_enabled == true and enabled ~= false
    if ok_enabled then
        table.insert(report.checks, report.watchdog_enabled and "watchdog_enabled" or "watchdog_disabled_by_setting")
    else
        report.success = false
        table.insert(report.messages, "Watchdog ayari okunamadi.")
    end

    if repair == true then
        if report.watchdog_enabled then
            local ok_install, install_success, install_message = pcall(function()
                return game_registry.ensure_cleanup_watchdog_installed()
            end)
            report.watchdog_repair = ok_install == true and install_success == true
            report.watchdog_message = tostring(install_message or "")
            if not report.watchdog_repair then
                report.success = false
                table.insert(report.messages, report.watchdog_message ~= "" and report.watchdog_message or "Watchdog onarilamadi.")
            end
        elseif ok_enabled then
            local ok_remove = pcall(game_registry.remove_cleanup_watchdog)
            report.watchdog_repair = ok_remove == true
        end
    end

    local ok_games, games = pcall(game_registry.list_registered_games)
    report.registered_games = ok_games and count_list(games) or 0
    if not ok_games then
        report.success = false
        table.insert(report.messages, "Kayitli oyun listesi okunamadi.")
    end

    local ok_account, account = pcall(auth.get_account)
    report.authenticated = ok_account == true and account and account.authenticated == true
    report.email = ok_account and account and account.user and account.user.email or ""
    report.hwid = ok_account and account and account.hwid or ""

    local ok_integrity, integrity = pcall(build_plugin_integrity_status)
    report.integrity = ok_integrity and integrity or { success = false, ok = false }
    report.integrity_ok = ok_integrity == true and integrity and integrity.ok == true
    if report.integrity_ok then
        table.insert(report.checks, "integrity_ok")
    else
        report.success = false
        table.insert(report.messages, "Plugin butunluk kontrolu uyari verdi.")
    end

    if report.success ~= true then report.shield = "warning" end
    report.summary = "Saglik kalkani " .. (report.success and "OK" or "uyari") ..
        " | oyun=" .. tostring(report.registered_games or 0) ..
        " | watchdog=" .. (report.watchdog_enabled and "aktif" or "pasif") ..
        " | hesap=" .. (report.authenticated and "var" or "yok")
    return report
end

local function build_smart_diagnostics()
    local report = {
        success = true,
        healthy = true,
        version = tostring(utils.get_plugin_version() or ""),
        problems = {},
        recommendations = {}
    }

    local ok_apis, apis = pcall(api_manifest.load_api_manifest)
    report.api_count = ok_apis and count_list(apis) or 0
    if not ok_apis or report.api_count == 0 then
        report.healthy = false
        table.insert(report.problems, "API kaynak listesi okunamadi.")
        table.insert(report.recommendations, "API listesini yenile.")
    end

    local ok_account, account = pcall(auth.get_account)
    report.account_readable = ok_account == true and type(account) == "table"
    report.authenticated = report.account_readable and account.authenticated == true
    if not report.account_readable then
        report.healthy = false
        table.insert(report.problems, "Hesap dosyasi okunamadi.")
    end

    local ok_games, games = pcall(game_registry.list_registered_games)
    report.registered_games = ok_games and count_list(games) or 0
    if not ok_games then
        report.healthy = false
        table.insert(report.problems, "Kayitli oyun listesi okunamadi.")
    end

    local ok_integrity, integrity = pcall(build_plugin_integrity_status)
    report.integrity = ok_integrity and integrity or { success = false, ok = false }
    if not ok_integrity or integrity.ok ~= true then
        report.healthy = false
        table.insert(report.problems, "Plugin dosya butunlugu uyari verdi.")
        table.insert(report.recommendations, "Plugin dosyalarini onar.")
    end

    report.summary = report.healthy and "Akilli teshis: sorun bulunmadi." or
        ("Akilli teshis: " .. tostring(#report.problems) .. " sorun bulundu.")
    return report
end

local function run_smart_repair(appid, reason)
    local actions = {}
    local function run_action(name, fn)
        local ok, result = pcall(fn)
        table.insert(actions, {
            name = name,
            success = ok == true and result ~= false,
            message = ok and tostring(result or "") or tostring(result)
        })
    end

    run_action("temp_hazirla", utils.ensure_temp_download_dir)
    run_action("indirme_kilidini_onar", function()
        return downloads.repair_state(tonumber(appid or 0))
    end)
    run_action("api_listesini_yenile", api_manifest.init_apis)
    run_action("temizleme_varliklarini_hazirla", game_registry.ensure_cleanup_assets)
    run_action("aktif_marker_yaz", game_registry.touch_active_marker)
    run_action("webkit_dosyalarini_esitle", function()
        if copy_webkit_files then copy_webkit_files() end
        return true
    end)

    local diagnostics = build_smart_diagnostics()
    diagnostics.repaired = true
    diagnostics.reason = tostring(reason or "")
    diagnostics.actions = actions
    diagnostics.message = diagnostics.healthy and "Akilli onarim tamamlandi." or
        "Akilli onarim tamamlandi; kalan uyarilari inceleyin."
    return diagnostics
end

local function ack_plugin_command(command_id, ok_value, result, status)
    if not command_id then return end
    local ok_ack, ack_result = pcall(auth.ack_command, command_id, ok_value, tostring(result or ""), status)
    if ok_ack and ack_result == true then
        logger.log("SecurityShoop command ack sent id=" .. tostring(command_id) .. ", ok=" .. tostring(ok_value ~= false))
    else
        logger.warn("SecurityShoop command ack failed id=" .. tostring(command_id) .. ", err=" .. tostring(ack_result))
    end
end

local function handle_plugin_command(command, defer_ack)
    if type(command) ~= "table" then return false, "Gecersiz komut." end
    local id = command.id
    local name = tostring(command.command or "")
    local payload = type(command.payload) == "table" and command.payload or {}
    local ok_value = true
    local result = "Komut tamamlandi."
    logger.log("SecurityShoop command received id=" .. tostring(id or "") .. ", command=" .. name)
    if not defer_ack then ack_plugin_command(id, true, "Komut calisiyor.", "running") end

    if name == "refresh_control" then
        local ok_status, status_result = pcall(auth.account_status)
        ok_value = ok_status and status_result and status_result.success == true
        if ok_value then
            pcall(function()
                auth.heartbeat("online", "", "", "Refresh control", nil, game_registry.list_registered_games())
            end)
        end
        result = ok_value and "Hesap ve kontrol durumu yenilendi." or tostring((status_result and status_result.error) or "Kontrol yenilenemedi.")
    elseif name == "logout" then
        pcall(auth.logout)
        result = "Hesaptan cikis yapildi."
    elseif name == "reset_account" then
        pcall(auth.logout)
        result = "Hesap oturumu sifirlandi."
    elseif name == "cleanup_games" then
        if payload.confirm_cleanup == true then
            ok_value, result = cleanup_installed_lua_scripts(payload.appids or payload.selected_appids)
        else
            ok_value = false
            result = "Guvenlik icin cleanup_games komutu admin onayi olmadan calismadi."
        end
    elseif name == "install_cleanup_watchdog" then
        ok_value, result = game_registry.install_cleanup_watchdog()
    elseif name == "remove_cleanup_watchdog" then
        ok_value, result = game_registry.remove_cleanup_watchdog()
    elseif name == "apply_settings" then
        local remote = type(payload.settings) == "table" and payload.settings or payload
        remote.enabled = true
        local apply_ok, apply_result = pcall(settings_manager.apply_remote_settings, remote)
        ok_value = apply_ok and type(apply_result) == "table" and apply_result.success == true
        result = ok_value and "Uzaktan plugin ayarlari uygulandi." or tostring((type(apply_result) == "table" and apply_result.error) or apply_result or "Ayarlar uygulanamadi.")
    elseif name == "cleanup_old_files" then
        local enabled, days = settings_manager.get_auto_cleanup_settings()
        if enabled == false and payload.force ~= true then
            ok_value = false
            result = "Otomatik eski dosya temizligi kapali."
        else
            local cleanup_result = temp_cleanup.run(payload.retention_days or days, true)
            ok_value = cleanup_result.success == true
            result = cleanup_result.message or cleanup_result.error or "Eski dosya temizligi tamamlandi."
        end
    elseif name == "health_check" then
        local report = build_plugin_health_shield_status(false)
        ok_value = report.success == true
        result = report.summary or "Saglik kalkani kontrol edildi."
    elseif name == "repair_health_shield" then
        local report = build_plugin_health_shield_status(true)
        ok_value = report.success == true
        result = report.summary or "Saglik kalkani onarildi."
    elseif name == "integrity_check" then
        local report = build_plugin_integrity_status()
        ok_value = report.ok == true
        result = report.message or "Plugin butunlugu kontrol edildi."
    elseif name == "repair_integrity" then
        if copy_webkit_files then pcall(copy_webkit_files) end
        pcall(game_registry.ensure_cleanup_assets)
        local report = build_plugin_integrity_status()
        ok_value = report.ok == true
        result = report.message or "Plugin butunlugu onarildi."
    elseif name == "send_notice" then
        ok_value = true
        result = tostring(payload.message or payload.title or "Bildirim alindi.")
    else
        ok_value = false
        result = "Bilinmeyen komut: " .. name
    end

    logger.log("SecurityShoop command finished id=" .. tostring(id or "") .. ", command=" .. name .. ", ok=" .. tostring(ok_value) .. ", result=" .. tostring(result or ""))
    if not defer_ack then ack_plugin_command(id, ok_value, result) end
    return ok_value, result
end

local function handle_plugin_commands(commands, defer_ack)
    if type(commands) ~= "table" then return 0, {} end
    local count = 0
    local acknowledgements = {}
    for _, command in ipairs(commands) do
        count = count + 1
        local ok, command_ok, result = pcall(handle_plugin_command, command, defer_ack)
        if not ok then
            result = "Komut calisirken hata: " .. tostring(command_ok)
            command_ok = false
            if not defer_ack then ack_plugin_command(command and command.id, false, result) end
        end
        table.insert(acknowledgements, {
            id = command and command.id,
            ok = command_ok == true,
            result = tostring(result or ""),
            status = command_ok == true and "completed" or "failed"
        })
        local command_name = type(command) == "table" and tostring(command.command or "") or ""
        if command_name == "logout" or command_name == "reset_account" then
            break
        end
    end
    return count, acknowledgements
end

-- ── Webkit file management ───────────────────────────────────────────────────

copy_webkit_files = function()
    local steam_dir = steam_utils.detect_steam_install_path()
    if not steam_dir or steam_dir == "" then return end

    local target_webkit_dir = fs.join(steam_dir, "steamui", "webkit")
    if not fs.exists(target_webkit_dir) then
        fs.create_directories(target_webkit_dir)
    end

    local public_dir = fs.join(paths.get_plugin_dir(), "public")

    local src_js = fs.join(public_dir, "luatools.js")
    local dst_js = fs.join(target_webkit_dir, "luatools.js")
    if fs.exists(src_js) then
        local content = m_utils.read_file(src_js)
        if content then m_utils.write_file(dst_js, content) end
    end

    local src_css = fs.join(public_dir, "steamdb-webkit.css")
    local dst_css = fs.join(target_webkit_dir, "steamdb-webkit.css")
    if fs.exists(src_css) then
        local content = m_utils.read_file(src_css)
        if content then m_utils.write_file(dst_css, content) end
    end
end

local function inject_webkit_files()
    millennium.add_browser_css("webkit/steamdb-webkit.css")
    millennium.add_browser_js("webkit/luatools.js")
end

-- ── Lifecycle ────────────────────────────────────────────────────────────────

local function on_load()
    logger.log("Bootstrapping SecurityShoop plugin, millennium " .. millennium.version())
    steam_utils.detect_steam_install_path()
    utils.ensure_temp_download_dir()

    local ok_s, err_s = pcall(settings_manager.init_settings)
    if not ok_s then logger.warn("settings init failed: " .. tostring(err_s)) end

    pcall(function()
        local cleanup_enabled, cleanup_days = settings_manager.get_auto_cleanup_settings()
        if cleanup_enabled then
            local report = temp_cleanup.run(cleanup_days, false)
            if report and tonumber(report.removed or 0) > 0 then
                activity_log.add("old_files_cleaned", { removed = report.removed, retention_days = cleanup_days })
            end
        end
    end)

    pcall(game_registry.ensure_cleanup_assets)
    pcall(game_registry.touch_active_marker)
    pcall(activity_log.seed_games, game_registry.list_registered_games())
    local ok_watchdog_enabled, watchdog_enabled = pcall(settings_manager.get_cleanup_watchdog_enabled)
    if ok_watchdog_enabled and watchdog_enabled ~= false then
        local ok_w, msg_w = pcall(game_registry.ensure_cleanup_watchdog_installed)
        if not ok_w then logger.warn("cleanup watchdog install failed: " .. tostring(msg_w)) end
    else
        pcall(game_registry.remove_cleanup_watchdog)
    end

    local ok_u, upd_msg = pcall(auto_update.apply_pending_update_if_any)
    if ok_u and upd_msg and upd_msg ~= "" then
        api_manifest.store_last_message(upd_msg)
    end

    copy_webkit_files()
    inject_webkit_files()

    local res = api_manifest.init_apis()
    logger.log("InitApis (boot) result: " .. tostring(res.message or ""))

    millennium.ready()
    pcall(auto_update.mark_current_boot_healthy)

    local keys = {}
    for k, v in pairs(millennium) do table.insert(keys, k .. ":" .. type(v)) end
    logger.log("MILLENNIUM KEYS: " .. table.concat(keys, ", "))
end

local function on_unload()
    logger.log("unloading SecurityShoop plugin")
end

local function on_frontend_loaded()
    logger.log("Frontend loaded")
    copy_webkit_files()
    pcall(game_registry.touch_active_marker)
end

-- ── Logger (called as "Logger.log" from JS) ──────────────────────────────────

Logger = {}

function Logger.log(message)
    local msg = type(message) == "table" and tostring(message.message or "") or tostring(message or "")
    logger.log("[Frontend] " .. msg)
    return json_ok({ success = true })
end

function Logger.warn(message)
    local msg = type(message) == "table" and tostring(message.message or "") or tostring(message or "")
    logger.warn("[Frontend] " .. msg)
    return json_ok({ success = true })
end

function Logger.error(message)
    local msg = type(message) == "table" and tostring(message.message or "") or tostring(message or "")
    logger.error("[Frontend] " .. msg)
    return json_ok({ success = true })
end

-- Millennium looks up "Logger.log" as a dotted global key
_G["Logger.log"]   = Logger.log
_G["Logger.warn"]  = Logger.warn
_G["Logger.error"] = Logger.error

-- ── Exported API Methods ─────────────────────────────────────────────────────
-- Every function returns a JSON string, matching the Python backend exactly.

function GetPluginDir()
    return paths.get_plugin_dir() -- plain string, matches Python
end

function InitApis()
    local ok, res = pcall(api_manifest.init_apis)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function GetInitApisMessage()
    local ok, res = pcall(api_manifest.get_init_apis_message)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function GetAuthState()
    local ok, res = pcall(auth.get_account)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function LoginAccount(first, second, third)
    local payload = decode_payload_arg(first) or decode_payload_arg(second) or decode_payload_arg(third)
    local email, password
    if payload then
        email = payload.email or payload.login or payload.username
        password = payload.password
    elseif looks_like_email(first) then
        email = first
        password = second
    else
        email = second
        password = third
    end
    local cleanEmail = value_or_empty(email)
    local cleanPassword = value_or_empty(password)
    logger.log("LoginAccount parsed email=" .. cleanEmail .. ", password_len=" .. tostring(#cleanPassword))
    local ok, res = pcall(auth.login, cleanEmail, cleanPassword)
    if not ok then return json_err(res) end
    if res and res.success == false and tonumber(res.status or 0) == 400 and looks_like_email(cleanEmail) then
        local reg_ok, reg_res = pcall(auth.register, username_from_email(cleanEmail), cleanEmail, cleanPassword, cleanPassword)
        if reg_ok and reg_res and reg_res.success then
            reg_res.message = "Hesap olusturuldu ve giris yapildi."
            return json_ok(compact_auth_result(reg_res))
        end
    end
    return json_ok(compact_auth_result(res))
end

function RegisterAccount(first, second, third, fourth, fifth)
    local payload = decode_payload_arg(first) or decode_payload_arg(second) or decode_payload_arg(third) or decode_payload_arg(fourth) or decode_payload_arg(fifth)
    local username, email, password, confirmPassword

    if payload then
        username = payload.username
        email = payload.email
        password = payload.password
        confirmPassword = payload.confirmPassword or payload.confirm_password
    elseif looks_like_email(second) then
        email = second
        password = third
        username = fourth
        confirmPassword = fifth
    elseif looks_like_email(third) then
        confirmPassword = first
        email = third
        password = fourth
        username = fifth
    elseif looks_like_email(first) then
        email = first
        password = second
        username = third
        confirmPassword = fourth
    else
        confirmPassword = first
        email = third
        password = fourth
        username = fifth
    end

    email = value_or_empty(email)
    password = value_or_empty(password)
    confirmPassword = value_or_empty(confirmPassword)
    username = value_or_empty(username)
    if username == "" then username = username_from_email(email) end
    if confirmPassword == "" then confirmPassword = password end

    logger.log("RegisterAccount parsed email=" .. email .. ", username=" .. username .. ", password_len=" .. tostring(#password))
    local ok, res = pcall(auth.register, username, email, password, confirmPassword)
    if not ok then return json_err(res) end
    return json_ok(compact_auth_result(res))
end

function SaveAccountSession(first, second, third)
    local payload = decode_payload_arg(first) or decode_payload_arg(second) or decode_payload_arg(third) or {}
    local ok, res = pcall(auth.save_session, payload.user, payload.message)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function LogoutAccount()
    local ok, res = pcall(auth.logout)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function RefreshAccountStatus()
    local ok, res = pcall(auth.account_status)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function SendHeartbeatNow(first, second, third)
    local payload = decode_payload_arg(first) or decode_payload_arg(second) or decode_payload_arg(third) or {}
    local status = payload.status or first or "online"
    local appid = payload.appid or ""
    local api_name = payload.apiName or payload.api_name or payload.current_api or ""
    local message = payload.message or ""

    local games = {}
    pcall(function() games = game_registry.list_registered_games() end)
    local ok, res = pcall(auth.heartbeat, status, appid, api_name, message, nil, games)
    if not ok then return json_err(res) end
    if res and res.commands then
        res.commands_processed = handle_plugin_commands(res.commands)
    end
    return json_ok(res)
end

function ApplyBrowserSiteSync(first, second, third)
    local payload = decode_payload_arg(first) or decode_payload_arg(second) or decode_payload_arg(third) or {}
    local account_status = payload.account_status
    local control = payload.control
    local heartbeat = payload.heartbeat
    if type(account_status) == "table" then pcall(auth.apply_browser_account_status, account_status) end
    if type(control) == "table" then pcall(auth.apply_browser_control, control) end
    local remote_result = nil
    if type(control) == "table" and type(control.control) == "table" then
        local remote = control.control.remote_settings
        if type(remote) == "table" then
            local ok_remote, applied = pcall(settings_manager.apply_remote_settings, remote)
            if ok_remote then remote_result = applied end
            pcall(function()
                local watchdog_enabled = settings_manager.get_cleanup_watchdog_enabled()
                if watchdog_enabled then game_registry.ensure_cleanup_watchdog_installed()
                else game_registry.remove_cleanup_watchdog() end
                local cleanup_enabled, cleanup_days = settings_manager.get_auto_cleanup_settings()
                if cleanup_enabled then temp_cleanup.run(cleanup_days, false) end
            end)
        end
    end
    if type(heartbeat) == "table" and (heartbeat.blocked == true or heartbeat.force_logout == true or heartbeat.session_revoked == true or heartbeat.authenticated == false) then
        pcall(auth.apply_browser_account_status, heartbeat)
    end
    local commands = type(heartbeat) == "table" and heartbeat.commands or {}
    local count, acknowledgements = handle_plugin_commands(commands, true)
    return json_ok({
        success = true,
        commands_processed = count,
        acknowledgements = acknowledgements,
        control_applied = type(control) == "table",
        account_applied = type(account_status) == "table",
        remote_settings = remote_result
    })
end

function GetInstalledSecurityShoopGames()
    local ok, res = pcall(game_registry.list_registered_games)
    if not ok then return json_err(res) end
    return json_ok({ success = true, games = res or {} })
end

function GetSecurityShoopHistory()
    local ok, res = pcall(activity_log.list, 50)
    if not ok then return json_err(res) end
    return json_ok({ success = true, events = res or {} })
end

function GetSecurityShoopQuarantine()
    local ok, res = pcall(package_guard.list)
    if not ok then return json_err(res) end
    return json_ok({ success = true, items = res or {} })
end

function GetOldFileCleanupStatus()
    local ok, res = pcall(temp_cleanup.status)
    if not ok then return json_err(res) end
    local enabled, days = settings_manager.get_auto_cleanup_settings()
    res.enabled = enabled
    res.retention_days = days
    return json_ok(res)
end

function RunOldFileCleanup(first, second, third)
    local payload = decode_payload_arg(first) or decode_payload_arg(second) or decode_payload_arg(third) or {}
    local enabled, days = settings_manager.get_auto_cleanup_settings()
    if not enabled and payload.force ~= true then return json_err("Otomatik eski dosya temizligi kapali.") end
    local ok, res = pcall(temp_cleanup.run, payload.retention_days or days, true)
    if not ok then return json_err(res) end
    if tonumber(res.removed or 0) > 0 then pcall(activity_log.add, "old_files_cleaned", { removed = res.removed, retention_days = res.retention_days }) end
    return json_ok(res)
end

function GetRemoteSettingsState()
    local ok, res = pcall(settings_manager.get_remote_settings_state)
    if not ok then return json_err(res) end
    return json_ok({ success = true, remote = res or {}, values = settings_manager.get_settings_state().values })
end

function GetCleanupProtectionStatus()
    local ok_assets = pcall(game_registry.ensure_cleanup_assets)
    local ok_touch = pcall(game_registry.touch_active_marker)
    local ok_enabled, enabled = pcall(settings_manager.get_cleanup_watchdog_enabled)
    return json_ok({
        success = ok_assets == true,
        active_marker = ok_touch == true,
        watchdog_enabled = ok_enabled and enabled ~= false
    })
end

function GetPluginHealthShieldStatus()
    local ok, res = pcall(build_plugin_health_shield_status, false)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function RepairPluginHealthShield()
    local ok, res = pcall(build_plugin_health_shield_status, true)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function GetPluginIntegrityStatus()
    local ok, res = pcall(build_plugin_integrity_status)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function RepairPluginIntegrity()
    if copy_webkit_files then pcall(copy_webkit_files) end
    pcall(game_registry.ensure_cleanup_assets)
    local ok, res = pcall(build_plugin_integrity_status)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function GetSmartDiagnostics()
    local ok, res = pcall(build_smart_diagnostics)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function RunSmartRepair(first, second, third)
    local payload = decode_payload_arg(first) or decode_payload_arg(second) or decode_payload_arg(third) or {}
    local appid = tonumber(payload.appid or first or 0) or 0
    local reason = tostring(payload.reason or "")
    local ok, res = pcall(run_smart_repair, appid, reason)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function InstallCleanupWatchdog()
    local ok, success, message = pcall(function()
        return game_registry.install_cleanup_watchdog()
    end)
    if not ok then return json_err(success) end
    return json_ok({ success = success == true, message = tostring(message or "") })
end

function RemoveCleanupWatchdog()
    local ok, success, message = pcall(function()
        return game_registry.remove_cleanup_watchdog()
    end)
    if not ok then return json_err(success) end
    return json_ok({ success = success == true, message = tostring(message or "") })
end

function GetPluginNotifications()
    local ok, res = pcall(auth.notifications)
    if not ok then return json_err(res) end
    return json_ok(res)
end

local function compare_versions(a, b)
    local ta = utils.parse_version(a)
    local tb = utils.parse_version(b)
    local len = math.max(#ta, #tb)
    for i = 1, len do
        local ai = ta[i] or 0
        local bi = tb[i] or 0
        if ai < bi then return -1 end
        if ai > bi then return 1 end
    end
    return 0
end

local function normalize_update_url(url)
    url = tostring(url or "")
    if url:sub(1, 1) == "/" then
        return "https://securityshoop.vercel.app" .. url
    end
    return url
end

function ReportPluginError(first, second, third, fourth)
    local payload = decode_payload_arg(first) or decode_payload_arg(second) or decode_payload_arg(third) or decode_payload_arg(fourth)
    local message, context, severity, page_url
    if payload then
        message = payload.message
        context = payload.context
        severity = payload.severity
        page_url = payload.pageUrl or payload.page_url
    else
        message = first
        context = second
        severity = third
        page_url = fourth
    end

    local ok, res = pcall(auth.report_error, value_or_empty(message), value_or_empty(context), value_or_empty(severity), value_or_empty(page_url))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function FetchFreeApisNow()
    local ok, res = pcall(api_manifest.fetch_free_apis_now)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function CheckForUpdatesNow()
    local ok_control, control_res = pcall(auth.control)
    if ok_control and control_res and control_res.success and type(control_res.control) == "table" then
        local control = control_res.control
        local current_version = utils.get_plugin_version()
        local latest_version = tostring(control.latest_version or "")
        local zip_url = normalize_update_url(control.update_url or "/securityshoop-plugin.zip")
        if latest_version ~= "" and zip_url ~= "" and compare_versions(latest_version, current_version) > 0 then
            return json_ok({
                success = true,
                update_available = true,
                latest_version = latest_version,
                current_version = current_version,
                zip_url = zip_url,
                release_notes = tostring(control.release_notes or ""),
                expected_sha256 = tostring(type(control.release_integrity) == "table" and control.release_integrity.sha256 or ""),
                release_signature = tostring(type(control.release_integrity) == "table" and control.release_integrity.signature or ""),
                force_update = control.force_update == true,
                message = "Guncelleme hazir: " .. latest_version .. ". Onaylarsan indirip uygular; Steam otomatik kapanip acilmaz."
            })
        end
        if latest_version ~= "" then
            return json_ok({
                success = true,
                update_available = false,
                latest_version = latest_version,
                current_version = current_version,
                zip_url = zip_url,
                message = "Guncelleme yok. Mevcut surum: " .. current_version
            })
        end
    end

    local ok, res = pcall(auto_update.check_for_updates_now)
    if not ok then
        logger.warn("CheckForUpdatesNow failed: " .. tostring(res))
        return json_err(res)
    end
    return json_ok(res)
end

function ApplyPluginUpdateNow(first, second, third)
    local payload = decode_payload_arg(first) or decode_payload_arg(second) or decode_payload_arg(third) or {}
    local zip_url = normalize_update_url(payload.zip_url or payload.url or "")
    local latest_version = tostring(payload.latest_version or payload.version or "")
    local expected_sha256 = tostring(payload.expected_sha256 or payload.sha256 or ""):lower()
    if zip_url == "" then return json_err("Guncelleme ZIP linki bos.") end
    if not expected_sha256:match("^[a-f0-9]+$") or #expected_sha256 ~= 64 then return json_err("Imzali guncelleme hash bilgisi eksik.") end
    local ok, res = pcall(auto_update.apply_update, zip_url, latest_version, expected_sha256)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function RestartSteam()
    local ok, success, message = pcall(auto_update.restart_steam)
    if ok and success then
        return json_ok({ success = true, message = tostring(message or "Steam yeniden baslatiliyor.") })
    end
    return json_ok({ success = false, error = ok and tostring(message or "Failed to restart Steam") or tostring(success) })
end

function HasLuaToolsForApp(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, exists = pcall(steam_utils.has_lua_for_app, tonumber(appid))
    if not ok then return json_err(exists) end
    return json_ok({ success = true, exists = exists == true })
end

function StartAddViaLuaTools(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(downloads.start_add_via_luatools, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function GetAddViaLuaToolsStatus(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(downloads.get_add_status, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function GetApiList()
    local ok, res = pcall(api_manifest.get_api_list)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function AddCustomApi(api_key, contentScriptQuery, name, url)
    -- JS passes: { api_key, contentScriptQuery, name, url }
    -- Reconstruct the payload object for api_manifest
    local payload = {
        name = tostring(name or ""),
        url = tostring(url or ""),
        api_key = tostring(api_key or "")
    }
    local ok, res = pcall(api_manifest.add_custom_api, payload)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function GetAllApis()
    local ok, res = pcall(api_manifest.get_all_apis)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function ToggleApi(params, contentScriptQuery)
    local apiName = params
    if type(params) == "table" then apiName = params.apiName or params.name end
    local ok, res = pcall(api_manifest.toggle_api, tostring(apiName or ""))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function RemoveApi(params, contentScriptQuery)
    local apiName = params
    if type(params) == "table" then apiName = params.apiName or params.name end
    local ok, res = pcall(api_manifest.remove_api, tostring(apiName or ""))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function RenameApi(params, contentScriptQuery)
    local old_name, new_name
    if type(params) == "table" then
        new_name = params.new_name
        old_name = params.old_name or params.apiName or params.name
    else
        -- If somehow positional
        old_name = params
    end
    local ok, res = pcall(api_manifest.rename_api, tostring(old_name or ""), tostring(new_name or ""))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function ReorderApis(params, contentScriptQuery)
    local names = params
    if type(params) == "table" and params.apiNames then
        names = params.apiNames
    end
    -- Millennium's Lua bridge doesn't deep-deserialize nested JSON arrays/objects
    if type(names) == "string" then
        local ok, parsed = pcall(cjson.decode, names)
        if ok and type(parsed) == "table" then
            names = parsed
        end
    end
    if type(names) ~= "table" then
        return json_ok({ success = false, error = "Invalid argument, got type: " .. type(names) })
    end
    local ok, res = pcall(api_manifest.set_api_order, names)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function CancelAddViaLuaTools(appid)
    -- No-op cancel stub; download is synchronous in Lua
    return json_ok({ success = true })
end

function CheckApisForApp(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(downloads.check_apis_for_app, tonumber(appid))
    if not ok then return json_err(res) end

    -- Ensure empty arrays encode as [] and not {}
    if res and type(res.results) == "table" and #res.results == 0 then
        local success_json = res.success and "true" or "false"
        return '{"success":' .. success_json .. ',"results":[]}'
    end

    return json_ok(res)
end

function GetMorrenusStats(api_key, force_refresh)
    if type(api_key) == "table" then
        force_refresh = api_key.force_refresh
        api_key = api_key.api_key
    end
    api_key = tostring(api_key or "")
    if api_key == "" then return json_err("api_key required") end
    local endpoint = "https://hubcapmanifest.com/api/v1/user/stats?api_key=" .. api_key
    local ok, resp = pcall(http_client.get, endpoint, { timeout = 10 })
    if ok and resp and resp.status == 200 then
        return resp.body -- already JSON string
    end
    return json_err("request failed")
end

function StartAddViaLuaToolsFromUrl(apiName, appid, contentScriptQuery, url)
    -- Millennium's IPC bridge sorts JS object keys alphabetically and passes their values as positional arguments.
    -- The JS passes: { apiName: ..., appid: ..., contentScriptQuery: "", url: ... }
    -- So the Lua signature MUST be (apiName, appid, contentScriptQuery, url)

    logger.log("StartAddViaLuaToolsFromUrl CALLED: appid=" ..
    tostring(appid) .. ", url=" .. tostring(url) .. ", apiName=" .. tostring(apiName))

    local ok, res = pcall(downloads.start_add_via_luatools_from_url, appid, url, apiName)
    if not ok then
        logger.warn("StartAddViaLuaToolsFromUrl CRASHED inside pcall: " .. tostring(res))
        return json_err(res)
    end

    return json_ok(res)
end

function FetchPackageBase64(first, second, third, fourth)
    local payload = decode_payload_arg(first) or decode_payload_arg(second) or decode_payload_arg(third) or decode_payload_arg(fourth) or {}
    local appid = tonumber(payload.appid or payload.app_id or 0)
    local url = tostring(payload.url or "")
    local api_name = tostring(payload.apiName or payload.api_name or "Backend")

    -- Millennium may pass JS object keys alphabetically as positional args:
    -- apiName, appid, contentScriptQuery, url.
    if (not appid or appid <= 0) and tonumber(second) then
        api_name = tostring(first or api_name)
        appid = tonumber(second)
        url = tostring(fourth or url)
    end

    -- Fallback for callers that pass appid first.
    if (not appid or appid <= 0) and tonumber(first) then
        appid = tonumber(first)
        url = tostring(second or url)
        api_name = tostring(third or api_name)
    end

    if not appid or appid <= 0 then return json_err("Invalid appid") end
    if not (url:sub(1, 7) == "http://" or url:sub(1, 8) == "https://") then
        return json_err("Invalid package URL")
    end

    local allowed, message = auth.ensure_can_add(appid, api_name)
    if not allowed then return json_err(message or "SecurityShoop hesap kontrolu basarisiz.") end

    logger.log("SecurityShoop: FetchPackageBase64 appid=" .. tostring(appid) .. " api=" .. api_name)
    local resp = http_client.get(url, {
        timeout = 60,
        headers = {
            ["User-Agent"] = "discord(dot)gg/luatools",
            ["Accept"] = "application/zip,application/octet-stream,*/*"
        }
    })
    if not resp or not resp.body then
        return json_err("Backend kaynak cevabi alamadi.")
    end
    local status = tonumber(resp.status or 0) or 0
    if not (status == 200 or status == 206) then
        return json_err("Backend kaynak cevap vermedi: HTTP " .. tostring(status))
    end
    if #resp.body == 0 then
        return json_err("Backend bos paket indirdi.")
    end
    if not package_body_looks_like_zip(resp.body) then
        return json_err("Backend kaynak ZIP yerine gecersiz cevap dondurdu.")
    end
    return json_ok({
        success = true,
        appid = appid,
        apiName = api_name,
        bytes = #resp.body,
        base64 = base64_encode(resp.body)
    })
end

function InstallGamePackageFiles(first, second, third, fourth, fifth)
    local payload = decode_payload_arg(first) or decode_payload_arg(second) or decode_payload_arg(third) or decode_payload_arg(fourth) or decode_payload_arg(fifth) or {}
    local appid = tonumber(payload.appid or 0)
    local api_name = tostring(payload.apiName or payload.api_name or "Browser")
    local game_name = tostring(payload.gameName or payload.game_name or ("AppID " .. tostring(appid or 0)))

    -- Millennium may pass JS object keys alphabetically as positional args:
    -- apiName, appid, contentScriptQuery, filesJson, gameName.
    if (not appid or appid <= 0) and tonumber(second) then
        api_name = tostring(first or api_name)
        appid = tonumber(second)
        payload.filesJson = tostring(fourth or payload.filesJson or "")
        game_name = tostring(fifth or game_name)
    end

    if not appid or appid <= 0 then return json_err("Invalid appid") end

    local files = payload.files
    if type(files) ~= "table" then
        local ok_files, decoded = pcall(cjson.decode, tostring(payload.filesJson or payload.files_json or "[]"))
        if ok_files and type(decoded) == "table" then files = decoded end
    end
    if type(files) ~= "table" or #files == 0 then return json_err("Paket dosyalari okunamadi.") end

    local allowed, message = auth.ensure_can_add(appid, api_name)
    if not allowed then return json_err(message or "SecurityShoop hesap kontrolu basarisiz.") end

    local steam_path = steam_utils.detect_steam_install_path()
    if not steam_path or steam_path == "" then return json_err("Steam klasoru bulunamadi.") end
    local target_dir = fs.join(steam_path, "config", "stplug-in")
    local depot_cache = fs.join(steam_path, "depotcache")
    if not fs.exists(target_dir) then fs.create_directories(target_dir) end
    if not fs.exists(depot_cache) then fs.create_directories(depot_cache) end

    local lua_text = ""
    local manifests = {}
    for _, item in ipairs(files) do
        local name = safe_package_filename(item.name)
        if name ~= "" then
            if name:match("%.manifest$") and type(item.base64) == "string" then
                local content = base64_decode(item.base64)
                if content ~= "" then
                    m_utils.write_file(fs.join(depot_cache, name), content)
                    table.insert(manifests, name)
                end
            elseif name == tostring(appid) .. ".lua" or (lua_text == "" and name:match("^%d+%.lua$")) then
                lua_text = tostring(item.text or "")
            end
        end
    end

    if lua_text == "" then return json_err("Paket icinde Lua dosyasi bulunamadi.") end
    lua_text = "-- SecurityShoop managed AppID " .. tostring(appid) .. "\n" ..
        "-- securityshoop-managed cleanup marker\n" ..
        "-- v8.5.2 no-cmd browser-install\n" ..
        lua_text
    local target_lua = fs.join(target_dir, tostring(appid) .. ".lua")
    m_utils.write_file(target_lua, lua_text)
    pcall(game_registry.record_game, appid, game_name, api_name, target_lua, manifests)
    pcall(downloads.mark_browser_install_done, appid, api_name)
    pcall(auth.log_action, "ADD_GAME", "appid=" .. tostring(appid) .. ", api=" .. api_name)
    pcall(function()
        auth.heartbeat("idle", appid, api_name, "Browser install completed", nil, game_registry.list_registered_games())
    end)
    return json_ok({ success = true, installedPath = target_lua, manifests = manifests, message = "Oyun dosyalari CMD acmadan kuruldu." })
end

function GetIconDataUrl()
    -- Python read an icon file from the public dir and base64-encoded it
    local icon_path = fs.join(paths.get_plugin_dir(), "public", "luatools-icon.png")
    if fs.exists(icon_path) then
        local content = m_utils.read_file(icon_path)
        if content then
            return json_ok({ success = true, dataUrl = "data:image/png;base64," ..
            (m_utils.base64_encode and m_utils.base64_encode(content) or "") })
        end
    end
    return json_ok({ success = false, error = "icon not found" })
end

function GetGamesDatabase()
    local ok, res = pcall(function()
        local db_path = paths.backend_path("data/applist.json")
        if fs.exists(db_path) then
            local data = utils.read_json(db_path)
            return { success = true, apps = data.apps or data or {} }
        end
        return { success = true, apps = {} }
    end)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function ReadLoadedApps()
    local ok, res = pcall(function()
        local log_path = paths.backend_path("loadedappids.txt")
        local apps = {}
        if fs.exists(log_path) then
            local text = utils.read_text(log_path)
            for line in (text .. "\n"):gmatch("([^\n]*)\n") do
                local appid = tonumber(line:match("^%s*(%d+)%s*$"))
                if appid then table.insert(apps, appid) end
            end
        end
        return { success = true, apps = apps }
    end)
    if not ok then return json_err(res) end
    return json_ok(res)
end

function DismissLoadedApps()
    local ok, err = pcall(function()
        local log_path = paths.backend_path("loadedappids.txt")
        if fs.exists(log_path) then
            m_utils.write_file(log_path, "")
        end
    end)
    if not ok then return json_err(err) end
    return json_ok({ success = true })
end

function DeleteLuaToolsForApp(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, success, message, cleaned = pcall(function()
        return game_registry.cleanup_games({ tostring(appid or "") })
    end)
    if not ok then return json_err(success) end
    return json_ok({ success = success == true, message = tostring(message or ""), cleaned = cleaned or {} })
end

function CheckForFixes(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(fixes.check_for_fixes, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function ApplyGameFix(appid, contentScriptQuery, downloadUrl, fixType, gameName, installPath)
    -- Millennium's IPC bridge sorts JS object keys alphabetically and passes their values as positional arguments.
    -- The JS passes: { appid, contentScriptQuery, downloadUrl, fixType, gameName, installPath }
    -- So the Lua signature MUST be (appid, contentScriptQuery, downloadUrl, fixType, gameName, installPath)

    local ok, res = pcall(fixes.apply_game_fix,
        tonumber(appid), tostring(downloadUrl or ""),
        tostring(installPath or ""), tostring(fixType or ""), tostring(gameName or ""))
    if not ok then
        logger.warn("ApplyGameFix CRASHED: " .. tostring(res))
        return json_err(res)
    end
    return json_ok(res)
end

function GetApplyFixStatus(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(fixes.get_apply_status, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function CancelApplyFix(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(fixes.cancel_apply, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function UninstallFix(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(fixes.uninstall_fix, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function UnFixGame(appid, installPath, fixDate)
    if type(appid) == "table" then
        installPath = appid.installPath; fixDate = appid.fixDate; appid = appid.appid
    end
    -- Stub - unfix logic not yet ported
    return json_ok({ success = false, error = "Not yet implemented" })
end

function GetUnfixStatus(appid)
    return json_ok({ success = true, state = { status = "done" } })
end

function GetInstalledFixes()
    return '{"success":true,"fixes":[]}'
end

function GetInstalledLuaScripts()
    -- Legacy settings-panel API. Keep this response minimal: Millennium v3.2.0 can
    -- crash natively when this bridge call is followed by another backend log call.
    return '{"success":true,"scripts":[],"count":0,"bridge_safe_array":true,"native_safe":"v8.5.2-security"}'
end

function GetGameInstallPath(appid)
    if type(appid) == "table" then appid = appid.appid end
    local ok, res = pcall(steam_utils.get_game_install_path_response, tonumber(appid))
    if not ok then return json_err(res) end
    return json_ok(res)
end

function OpenGameFolder(path)
    if type(path) == "table" then path = path.path end
    local ok, success = pcall(steam_utils.open_game_folder, tostring(path or ""))
    if ok and success then
        return json_ok({ success = true })
    end
    return json_ok({ success = false, error = "Failed to open path" })
end

function OpenExternalUrl(url)
    if type(url) == "table" then url = url.url end
    url = tostring(url or "")
    if not (url:sub(1, 7) == "http://" or url:sub(1, 8) == "https://") then
        return json_err("Invalid URL")
    end
    local is_win = (m_utils.getenv("OS") or ""):find("Windows") ~= nil
    if is_win then
        return json_ok({ success = false, error = "Dis URL acma kapali: CMD penceresi acilmamasi icin otomatik tarayici baslatilmiyor." })
    end
    return json_ok({ success = false, error = "Dis URL acma kapali: CMD/terminal penceresi acilmamasi icin otomatik tarayici baslatilmiyor." })
end

function GetSettingsConfig()
    local ok, payload = pcall(settings_manager.get_settings_payload)
    if not ok then
        logger.warn("GetSettingsConfig failed: " .. tostring(payload))
        return json_err(payload)
    end
    return json_ok({
        success       = true,
        schemaVersion = payload.version,
        schema        = payload.schema or {},
        values        = payload.values or {},
        language      = payload.language,
        locales       = payload.locales or {},
        translations  = payload.translations or {}
    })
end

function GetThemes()
    local themes_json_path = fs.join(paths.get_plugin_dir(), "public", "themes", "themes.json")
    local themes_array = {}

    if fs.exists(themes_json_path) then
        local success, data = pcall(cjson.decode, utils.read_text(themes_json_path))
        if success and type(data) == "table" then
            themes_array = data
        else
            logger.warn("GetThemes failed to decode themes.json")
        end
    else
        logger.warn("GetThemes: themes.json not found")
    end

    return json_ok({ success = true, themes = themes_array })
end

function ApplySettingsChanges(changes)
    -- Millennium may pass the argument as a JSON string rather than a decoded table.
    -- Mirror the Python version's parsing logic exactly.
    local payload = nil

    if type(changes) == "string" and changes ~= "" then
        -- Try to decode the JSON string
        local ok, decoded = pcall(cjson.decode, changes)
        if not ok then
            logger.warn("ApplySettingsChanges: failed to parse changes string")
            return json_err("Invalid JSON payload")
        end
        -- Unwrap nested wrappers the JS bridge sometimes adds
        if type(decoded) == "table" and decoded.changes then
            payload = decoded.changes
        elseif type(decoded) == "table" and type(decoded.changesJson) == "string" then
            local ok2, inner = pcall(cjson.decode, decoded.changesJson)
            if ok2 then payload = inner else return json_err("Invalid JSON payload") end
        else
            payload = decoded
        end
    elseif type(changes) == "table" then
        -- Already a decoded table – handle wrapper keys
        if changes.changes then
            payload = changes.changes
        elseif type(changes.changesJson) == "string" then
            local ok2, inner = pcall(cjson.decode, changes.changesJson)
            if ok2 then payload = inner else return json_err("Invalid JSON payload") end
        else
            payload = changes
        end
    else
        payload = {}
    end

    if payload == nil then payload = {} end

    if type(payload) ~= "table" then
        logger.warn("ApplySettingsChanges: payload is not a table: " .. tostring(payload))
        return json_err("Invalid payload format")
    end

    logger.log("ApplySettingsChanges payload: " .. (pcall(cjson.encode, payload) and cjson.encode(payload) or "?"))

    local ok, res = pcall(settings_manager.apply_settings_changes, payload)
    if not ok then
        logger.warn("ApplySettingsChanges failed: " .. tostring(res))
        return json_err(res)
    end
    return json_ok(res)
end

function GetAvailableLocales()
    local ok, locs = pcall(settings_manager.get_available_locales)
    if not ok then return json_err(locs) end
    return json_ok({ success = true, locales = locs })
end

function GetTranslations(language)
    -- Handle both {language="en"} table and plain string argument
    if type(language) == "table" then
        language = language.language or language.lang
    end
    language = tostring(language or locales_mod.DEFAULT_LOCALE)

    local ok, strings = pcall(function()
        return locales_mod.get_locale_manager():get_locale_strings(language)
    end)
    if not ok then
        logger.warn("GetTranslations failed: " .. tostring(strings))
        return json_err(strings)
    end

    -- Frontend expects: { success, strings:{...}, language, locales:[...] }
    local ok2, locs = pcall(settings_manager.get_available_locales)
    return json_ok({
        success  = true,
        strings  = strings or {},
        language = language,
        locales  = ok2 and locs or {}
    })
end

function GetAvailableThemes()
    return json_ok({ success = true, themes = {} })
end

-- ── Return lifecycle table ────────────────────────────────────────────────────

return {
    on_load            = on_load,
    on_unload          = on_unload,
    on_frontend_loaded = on_frontend_loaded,
}
