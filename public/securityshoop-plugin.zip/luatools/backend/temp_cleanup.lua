local cjson = require("json")
local fs = require("fs")
local m_utils = require("utils")
local paths = require("paths")
local utils = require("plugin_utils")

local cleanup = {}
local INDEX_FILE = paths.backend_path("data/temp-cleanup-index.json")
local MIN_INTERVAL_SECONDS = 6 * 60 * 60

local ACTIVE = {
    downloading = true,
    extracting = true,
    extracted = true,
    processing = true,
    installing = true,
    finalizing = true,
    waiting_network = true
}

local function recognized(name)
    if type(name) ~= "string" or name:find("[/\\]") then return nil end
    return name:match("^(%d+)%.zip$") or
        name:match("^(%d+)_state%.json$") or
        name:match("^(%d+)_state%.json%.tmp$") or
        name:match("^(%d+)_dl_hidden%.vbs$") or
        name:match("^(%d+)_dl%.ps1$") or
        name:match("^(%d+)_dl%.sh$") or
        name:match("^extracted_(%d+)$") or
        name:match("^fix_(%d+)%.zip$") or
        name:match("^fix_(%d+)_state%.json$") or
        name:match("^fix_(%d+)_request%.json$") or
        name:match("^fix_(%d+)_hidden%.vbs$") or
        name:match("^fix_(%d+)_cancel$")
end

local function download_is_active(root, appid)
    local state_path = fs.join(root, tostring(appid) .. "_state.json")
    if not fs.exists(state_path) then return false end
    local text = m_utils.read_file(state_path)
    if not text or text == "" then return false end
    local ok, state = pcall(cjson.decode, text)
    return ok and type(state) == "table" and ACTIVE[tostring(state.status or ""):lower()] == true
end

local function read_index()
    local data = utils.read_json(INDEX_FILE)
    if type(data) ~= "table" then data = {} end
    if type(data.items) ~= "table" then data.items = {} end
    return data
end

function cleanup.run(retention_days, force)
    local now_epoch = os.time()
    local days = math.max(1, math.min(90, math.floor(tonumber(retention_days or 7) or 7)))
    local index = read_index()
    if force ~= true and now_epoch - (tonumber(index.last_run_epoch or 0) or 0) < MIN_INTERVAL_SECONDS then
        return { success = true, skipped = true, removed = 0, retention_days = days, message = "Eski dosya temizligi daha once calisti." }
    end

    local root = utils.ensure_temp_download_dir()
    local seen = {}
    local removed = 0
    local failed = 0
    local active = 0
    local ok_list, entries = pcall(fs.list, root)
    if not ok_list or type(entries) ~= "table" then
        return { success = false, removed = 0, error = "Gecici dosya klasoru okunamadi." }
    end

    for _, entry in ipairs(entries) do
        local name = tostring(entry.name or "")
        local appid = recognized(name)
        if appid then
            seen[name] = true
            local item = type(index.items[name]) == "table" and index.items[name] or {}
            item.first_seen_epoch = tonumber(item.first_seen_epoch or now_epoch) or now_epoch
            item.last_seen_epoch = now_epoch
            item.appid = tostring(appid)
            if download_is_active(root, appid) then
                item.first_seen_epoch = now_epoch
                active = active + 1
            elseif now_epoch - item.first_seen_epoch >= days * 24 * 60 * 60 then
                local path = fs.join(root, name)
                local ok_remove
                if entry.is_directory then ok_remove = pcall(fs.remove_all, path)
                else ok_remove = pcall(fs.remove, path) end
                if ok_remove and not fs.exists(path) then
                    removed = removed + 1
                    item = nil
                else
                    failed = failed + 1
                end
            end
            if item then index.items[name] = item else index.items[name] = nil end
        end
    end

    for name in pairs(index.items) do
        if not seen[name] then index.items[name] = nil end
    end
    index.last_run_epoch = now_epoch
    index.last_run_at = os.date("!%Y-%m-%dT%H:%M:%SZ")
    index.last_removed = removed
    index.retention_days = days
    utils.write_json(INDEX_FILE, index)
    return {
        success = failed == 0,
        removed = removed,
        failed = failed,
        active = active,
        retention_days = days,
        message = tostring(removed) .. " eski gecici dosya temizlendi."
    }
end

function cleanup.status()
    local data = read_index()
    local tracked = 0
    for _ in pairs(type(data.items) == "table" and data.items or {}) do tracked = tracked + 1 end
    return {
        success = true,
        last_run_at = data.last_run_at or "",
        last_removed = tonumber(data.last_removed or 0) or 0,
        retention_days = tonumber(data.retention_days or 7) or 7,
        tracked = tracked
    }
end

return cleanup
